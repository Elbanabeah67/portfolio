import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, User, MessageCircle, ExternalLink } from 'lucide-react';
import { portfolioData } from '../data/portfolioData';

const Feedback = () => {
  const [reviews, setReviews] = useState(() => {
    const saved = localStorage.getItem('blacker-reviews');
    if (saved) return JSON.parse(saved);
    return [];
  });
  
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [discordUsername, setDiscordUsername] = useState('');
  const [reviewText, setReviewText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    localStorage.setItem('blacker-reviews', JSON.stringify(reviews));
  }, [reviews]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!discordUsername.trim()) {
      alert('Please enter your Discord username');
      return;
    }

    setIsSubmitting(true);

    const newReview = {
      id: Date.now(),
      discordUsername: discordUsername.trim(),
      rating: rating,
      review: reviewText.trim(),
      date: new Date().toISOString(),
      discordLink: `https://discord.com/users/${discordUsername.trim()}`
    };

    setTimeout(() => {
      setReviews(prev => [newReview, ...prev]);
      setRating(5);
      setDiscordUsername('');
      setReviewText('');
      setIsSubmitting(false);
    }, 500);
  };

  // SVG نجمة يدوية
  const StarIcon = ({ filled, size = 24 }) => (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 24 24" 
      fill={filled ? "#f5af19" : "none"} 
      stroke="#f5af19" 
      strokeWidth="1.5"
      style={{ cursor: 'pointer' }}
    >
      <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
    </svg>
  );

  const StarRating = ({ rating, onRatingChange, onHoverChange, size = 28 }) => {
    const stars = [1, 2, 3, 4, 5];
    
    return (
      <div style={{ display: 'flex', gap: '8px' }}>
        {stars.map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onRatingChange(star)}
            onMouseEnter={() => onHoverChange(star)}
            onMouseLeave={() => onHoverChange(0)}
            style={{
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              padding: 0,
              transition: 'transform 0.2s ease'
            }}
            onMouseEnter={(e) => e.currentTarget.style.transform = 'scale(1.1)'}
            onMouseLeave={(e) => e.currentTarget.style.transform = 'scale(1)'}
          >
            <StarIcon filled={(hoverRating || rating) >= star} size={size} />
          </button>
        ))}
      </div>
    );
  };

  const totalReviews = reviews.length;
  const averageRating = reviews.length > 0 
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : 0;

  return (
    <section id="feedback" className="feedback-section">
      <div className="feedback-container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="feedback-header"
        >
          <h2 className="feedback-title">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="#f5af19" stroke="#f5af19" strokeWidth="1.5" style={{ display: 'inline', marginRight: '8px' }}>
              <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
            </svg>
            REVIEWS & RATINGS
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="feedback-form-card glass-panel"
        >
          <h3 className="form-title">RATE THIS DEVELOPER</h3>
          
          <form onSubmit={handleSubmit} className="feedback-form">
            <div className="form-rating">
              <label className="form-label">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#f5af19" stroke="#f5af19" strokeWidth="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#f5af19" stroke="#f5af19" strokeWidth="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#f5af19" stroke="#f5af19" strokeWidth="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#f5af19" stroke="#f5af19" strokeWidth="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="#f5af19" stroke="#f5af19" strokeWidth="1.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" /></svg>
              </label>
              <StarRating 
                rating={rating}
                onRatingChange={setRating}
                onHoverChange={setHoverRating}
                size={32}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Write a review (optional)...</label>
              <textarea
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                placeholder="Share your experience working with Blacker..."
                className="form-input form-textarea"
                rows="3"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Discord username (required)</label>
              <div className="discord-input-wrapper">
                <User size={18} className="input-icon" />
                <input
                  type="text"
                  value={discordUsername}
                  onChange={(e) => setDiscordUsername(e.target.value)}
                  placeholder="e.g., blacker#1234 or username"
                  className="form-input"
                  required
                />
              </div>
            </div>

            <button type="submit" disabled={isSubmitting} className="submit-review-btn">
              {isSubmitting ? (
                <span className="spinner" />
              ) : (
                <>
                  <Send size={16} />
                  SUBMIT REVIEW
                </>
              )}
            </button>
          </form>
        </motion.div>

        {totalReviews > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="reviews-stats"
          >
            <div className="stats-badge">
              <span className="stats-average">{averageRating}</span>
              <div className="stats-stars">
                {[1, 2, 3, 4, 5].map(star => (
                  <svg key={star} width="16" height="16" viewBox="0 0 24 24" fill={star <= Math.round(parseFloat(averageRating)) ? "#f5af19" : "none"} stroke="#f5af19" strokeWidth="1.5">
                    <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                  </svg>
                ))}
              </div>
              <span className="stats-count">({totalReviews} reviews)</span>
            </div>
          </motion.div>
        )}

        <div className="reviews-list">
          <AnimatePresence>
            {reviews.length === 0 ? (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="empty-reviews"
              >
                <MessageCircle size={48} />
                <p>No reviews yet. Be the first to rate!</p>
              </motion.div>
            ) : (
              reviews.map((review, index) => (
                <motion.div
                  key={review.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4, delay: index * 0.05 }}
                  className="review-card glass-panel"
                >
                  <div className="review-header">
                    <a 
                      href={review.discordLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="review-user-link"
                    >
                      <User size={18} />
                      <span className="review-username">{review.discordUsername}</span>
                      <ExternalLink size={12} />
                    </a>
                    <div className="review-rating">
                      {[1, 2, 3, 4, 5].map(star => (
                        <svg key={star} width="14" height="14" viewBox="0 0 24 24" fill={star <= review.rating ? "#f5af19" : "none"} stroke="#f5af19" strokeWidth="1.5">
                          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                        </svg>
                      ))}
                    </div>
                  </div>
                  
                  {review.review && (
                    <p className="review-text">"{review.review}"</p>
                  )}
                  
                  <div className="review-date">
                    {new Date(review.date).toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'short', 
                      day: 'numeric' 
                    })}
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};

export default Feedback;