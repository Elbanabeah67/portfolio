import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useSpring } from 'framer-motion';
import { Terminal, Menu, X, Code2, Sparkles, User, Mail, Settings, Sun, Moon, Briefcase, UserCircle, Building2, Globe } from 'lucide-react';

const Navbar = ({ lang, setLang, theme, toggleTheme, t }) => {
  const [scrolled, setScrolled] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setSettingsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navLinks = [
    { name: 'Profile', href: '#profile', icon: <UserCircle size={16} /> },
    { name: 'About', href: '#about', icon: <User size={16} /> },
    { name: 'Projects', href: '#projects', icon: <Briefcase size={16} /> },
    { name: 'Skills', href: '#skills', icon: <Code2 size={16} /> },
    { name: 'Companies', href: '#companies', icon: <Building2 size={16} /> },
    { name: 'Contact', href: '#contact', icon: <Mail size={16} /> },
  ];

  // تعريف اللغات المدعومة
  const supportedLanguages = [
    { code: 'en', name: 'English' },
    { code: 'ar', name: 'العربية' },
    { code: 'fr', name: 'Français' },
    { code: 'es', name: 'Español' },
    { code: 'de', name: 'Deutsch' },
    { code: 'it', name: 'Italiano' },
    { code: 'pt', name: 'Português' },
    { code: 'ru', name: 'Русский' },
    { code: 'zh', name: '中文' },
    { code: 'ja', name: '日本語' },
    { code: 'ko', name: '한국어' },
    { code: 'hi', name: 'हिन्दी' },
    { code: 'tr', name: 'Türkçe' },
    { code: 'nl', name: 'Nederlands' },
    { code: 'pl', name: 'Polski' }
  ];

  const sidebarVariants = {
    open: {
      x: 0,
      transition: { type: 'spring', stiffness: 300, damping: 30 }
    },
    closed: {
      x: lang === 'ar' ? '-100%' : '100%',
      transition: { type: 'spring', stiffness: 300, damping: 30 }
    }
  };

  // الحصول على اسم اللغة الحالية
  const getCurrentLanguageName = () => {
    const currentLang = supportedLanguages.find(l => l.code === lang);
    return currentLang ? currentLang.name : 'English';
  };

  return (
    <>
      <motion.nav
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className={`navbar ${scrolled ? 'navbar-scrolled' : ''}`}
      >
        <div className="navbar-container">
          <a href="#hero" className="navbar-logo">
            <Terminal className="logo-icon" size={24} />
            <span className="logo-text">
              Blacker<span className="dot">.</span>
            </span>
          </a>

          <div className="navbar-menu-desktop">
            {navLinks.map((link) => (
              <a key={link.name} href={link.href} className="nav-item">
                <span className="nav-item-icon">{link.icon}</span>
                <span className="nav-item-text">{t.nav[link.name.toLowerCase()]}</span>
              </a>
            ))}
            <a href="#contact" className="navbar-cta-btn">
              <Sparkles size={16} />
              {t.hero.ctaTalk}
            </a>

            <div className="settings-dropdown-wrapper" ref={dropdownRef}>
              <button 
                className="navbar-settings-btn"
                onClick={() => setSettingsOpen(!settingsOpen)}
                aria-label={t.nav.settings}
              >
                <Settings 
                  size={20} 
                  style={{ 
                    transform: settingsOpen ? 'rotate(45deg)' : 'rotate(0deg)',
                    transition: 'transform 0.4s cubic-bezier(0.16, 1, 0.3, 1)' 
                  }} 
                />
              </button>

              <AnimatePresence>
                {settingsOpen && (
                  <motion.div
                    initial={{ opacity: 0, y: 15, scale: 0.95 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: 10, scale: 0.95 }}
                    transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
                    className="settings-dropdown-panel"
                    style={{
                      maxHeight: '80vh',
                      overflowY: 'auto'
                    }}
                  >
                    <div className="settings-group">
                      <span className="settings-group-label">{t.settings?.theme || 'Theme'}</span>
                      <div className="theme-toggle-group">
                        <button 
                          className={`theme-toggle-btn ${theme === 'dark' ? 'active' : ''}`}
                          onClick={() => toggleTheme('dark')}
                        >
                          <Moon size={14} />
                          {t.settings?.dark || 'Dark'}
                        </button>
                        <button 
                          className={`theme-toggle-btn ${theme === 'light' ? 'active' : ''}`}
                          onClick={() => toggleTheme('light')}
                        >
                          <Sun size={14} />
                          {t.settings?.light || 'Light'}
                        </button>
                      </div>
                    </div>

                    <div className="settings-group">
                      <span className="settings-group-label">{t.settings?.language || 'Language'}</span>
                      <div className="lang-select-wrapper">
                        <select 
                          className="lang-select"
                          value={lang}
                          onChange={(e) => setLang(e.target.value)}
                          style={{
                            width: '100%',
                            padding: '10px 12px',
                            borderRadius: '8px',
                            border: '1px solid var(--border-normal)',
                            background: 'var(--bg-secondary)',
                            color: 'var(--text-primary)',
                            fontSize: '14px',
                            cursor: 'pointer',
                            outline: 'none',
                            appearance: 'auto',
                            WebkitAppearance: 'auto',
                            MozAppearance: 'auto'
                          }}
                        >
                          {supportedLanguages.map((langOption) => (
                            <option key={langOption.code} value={langOption.code}>
                              {langOption.name}
                            </option>
                          ))}
                        </select>
                        <Globe size={16} className="lang-select-icon" />
                      </div>
                    </div>

                    {/* عرض اللغة الحالية */}
                    <div className="settings-group" style={{ borderTop: '1px solid var(--border-normal)', paddingTop: '12px', marginTop: '8px' }}>
                      <span className="settings-group-label" style={{ fontSize: '11px', opacity: 0.6 }}>
                        {t.settings?.currentLanguage || 'Current Language'}: {getCurrentLanguageName()}
                      </span>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

          <button 
            className="navbar-toggle-btn"
            onClick={() => setIsOpen(!isOpen)}
            aria-label="Toggle navigation menu"
          >
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        <motion.div className="scroll-progress" style={{ scaleX }} />
      </motion.nav>

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              className="navbar-backdrop"
              onClick={() => setIsOpen(false)}
            />
            <motion.div
              initial="closed"
              animate="open"
              exit="closed"
              variants={sidebarVariants}
              className="navbar-sidebar"
              style={{
                left: lang === 'ar' ? 0 : 'auto',
                right: lang === 'ar' ? 'auto' : 0,
                borderLeft: lang === 'ar' ? 'none' : '1px solid var(--border-normal)',
                borderRight: lang === 'ar' ? '1px solid var(--border-normal)' : 'none',
                maxHeight: '100vh',
                overflowY: 'auto'
              }}
            >
              <div className="sidebar-header">
                <a href="#hero" className="navbar-logo" onClick={() => setIsOpen(false)}>
                  <Terminal className="logo-icon" size={24} />
                  <span className="logo-text">Blacker<span className="dot">.</span></span>
                </a>
                <button 
                  className="sidebar-close-btn"
                  onClick={() => setIsOpen(false)}
                  aria-label="Close menu"
                >
                  <X size={24} />
                </button>
              </div>

              <div className="sidebar-links">
                {navLinks.map((link) => (
                  <a 
                    key={link.name} 
                    href={link.href} 
                    className="sidebar-link"
                    onClick={() => setIsOpen(false)}
                  >
                    <span className="sidebar-link-icon">{link.icon}</span>
                    <span>{t.nav[link.name.toLowerCase()]}</span>
                  </a>
                ))}
                <a 
                  href="#contact" 
                  className="sidebar-cta"
                  onClick={() => setIsOpen(false)}
                >
                  <Sparkles size={16} />
                  {t.hero.ctaTalk}
                </a>

                <div style={{ marginTop: 'auto', paddingTop: '24px', borderTop: '1px solid var(--border-normal)' }}>
                  <div className="settings-group" style={{ marginBottom: '16px' }}>
                    <span className="settings-group-label" style={{ marginBottom: '8px', display: 'block' }}>{t.settings?.theme || 'Theme'}</span>
                    <div className="theme-toggle-group">
                      <button 
                        className={`theme-toggle-btn ${theme === 'dark' ? 'active' : ''}`}
                        onClick={() => {
                          toggleTheme('dark');
                          setIsOpen(false);
                        }}
                      >
                        <Moon size={14} />
                        {t.settings?.dark || 'Dark'}
                      </button>
                      <button 
                        className={`theme-toggle-btn ${theme === 'light' ? 'active' : ''}`}
                        onClick={() => {
                          toggleTheme('light');
                          setIsOpen(false);
                        }}
                      >
                        <Sun size={14} />
                        {t.settings?.light || 'Light'}
                      </button>
                    </div>
                  </div>

                  <div className="settings-group">
                    <span className="settings-group-label" style={{ marginBottom: '8px', display: 'block' }}>{t.settings?.language || 'Language'}</span>
                    <select 
                      className="lang-select-sidebar"
                      value={lang}
                      onChange={(e) => {
                        setLang(e.target.value);
                        setIsOpen(false);
                      }}
                      style={{
                        width: '100%',
                        padding: '10px 12px',
                        borderRadius: '8px',
                        border: '1px solid var(--border-normal)',
                        background: 'var(--bg-secondary)',
                        color: 'var(--text-primary)',
                        fontSize: '14px',
                        cursor: 'pointer',
                        outline: 'none',
                        appearance: 'auto',
                        WebkitAppearance: 'auto',
                        MozAppearance: 'auto'
                      }}
                    >
                      {supportedLanguages.map((langOption) => (
                        <option key={langOption.code} value={langOption.code}>
                          {langOption.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div style={{ marginTop: '12px', fontSize: '12px', opacity: 0.6, textAlign: 'center' }}>
                    {t.settings?.currentLanguage || 'Current Language'}: {getCurrentLanguageName()}
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export default Navbar;