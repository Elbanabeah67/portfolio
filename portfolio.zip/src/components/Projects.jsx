import React from 'react';
import { motion } from 'framer-motion';
import { PackageX } from 'lucide-react';

const Projects = ({ t }) => {
  const { projects } = t;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30, scale: 0.98 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] }
    }
  };

  return (
    <section id="projects" className="projects-section">
      <div className="section-header-block">
        <motion.h2 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="section-title"
        >
          {projects.title}
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 0.7, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="section-subtitle-text"
        >
          {projects.subtitle}
        </motion.p>
      </div>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        className="projects-grid"
        style={{ display: 'flex', justifyContent: 'center' }}
      >
        <motion.div 
          variants={cardVariants}
          className="project-card glass-panel"
          whileHover={{ y: -8, transition: { duration: 0.2 } }}
          style={{ maxWidth: '450px', width: '100%', minHeight: '350px' }}
        >
          <div style={{ 
            display: 'flex', 
            flexDirection: 'column', 
            alignItems: 'center', 
            justifyContent: 'center',
            height: '100%',
            padding: '40px 20px',
            textAlign: 'center',
            gap: '20px'
          }}>
            <div style={{
              width: '80px',
              height: '80px',
              borderRadius: '50%',
              background: 'var(--bg-secondary)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              border: '2px dashed var(--border-normal)'
            }}>
              <PackageX size={40} style={{ opacity: 0.4 }} />
            </div>
            
            <h3 style={{ 
              fontSize: '24px', 
              fontWeight: '600',
              color: 'var(--text-primary)',
              margin: 0
            }}>
              غير متوفر حالياً
            </h3>
            
            <p style={{ 
              fontSize: '16px',
              color: 'var(--text-secondary)',
              opacity: 0.7,
              margin: 0,
              maxWidth: '300px'
            }}>
              سيتم إضافة المشاريع قريباً
            </p>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
};

export default Projects;