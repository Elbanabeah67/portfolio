import React from 'react';
import { motion } from 'framer-motion';

const Philosophy = ({ t }) => {
  return (
    <section id="philosophy" className="philosophy-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="philosophy-container glass-panel"
      >
        <span className="philosophy-badge">
          {t.lang === 'ar' ? 'المبدأ الأساسي' : 'Core Principle'}
        </span>
        <blockquote className="philosophy-quote">
          "{t.philosophy.quote}"
        </blockquote>
        <cite className="philosophy-author">— {t.philosophy.author}</cite>
      </motion.div>
    </section>
  );
};

export default Philosophy;
