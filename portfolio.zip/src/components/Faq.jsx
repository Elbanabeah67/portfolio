import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle } from 'lucide-react';

const Faq = ({ t }) => {
  const [activeIndex, setActiveIndex] = useState(null);
  const faqs = t.faq.items;

  return (
    <section id="faq" className="faq-section">
      <motion.h2 
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="section-title"
      >
        {t.faq.title}
      </motion.h2>

      <div className="faq-container">
        {faqs.map((faq, idx) => {
          const isOpen = activeIndex === idx;
          return (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: idx * 0.1 }}
              className={`faq-card glass-panel ${isOpen ? 'active' : ''}`}
            >
              <button 
                onClick={() => setActiveIndex(isOpen ? null : idx)}
                className="faq-question-btn"
                aria-expanded={isOpen}
              >
                <div className="faq-q-text-wrapper">
                  <HelpCircle size={18} className="faq-icon" />
                  <span className="faq-question">{faq.q}</span>
                </div>
                <motion.div
                  animate={{ rotate: isOpen ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                >
                  <ChevronDown size={18} className="faq-chevron" />
                </motion.div>
              </button>

              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.35, ease: "easeInOut" }}
                    className="faq-answer-wrapper"
                  >
                    <p className="faq-answer">
                      {faq.a}
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
};

export default Faq;
