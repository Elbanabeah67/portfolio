import React from 'react';
import { motion } from 'framer-motion';
import { AtSign, Hash, MapPin, Briefcase } from 'lucide-react';
import { portfolioData } from '../data/portfolioData';

const Profile = () => {
  const { profile } = portfolioData;

  return (
    <section id="profile" className="profile-section">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="profile-card glass-panel"
      >
        <div className="profile-avatar-wrapper">
          <img 
            src={profile.avatar} 
            alt={profile.name}
            className="profile-avatar"
            onError={(e) => {
              e.target.src = "https://ui-avatars.com/api/?name=" + profile.name + "&background=6366f1&color=fff";
            }}
          />
        </div>

        <div className="profile-info">
          <h2 className="profile-name">{profile.name}</h2>
          <p className="profile-role">{profile.role}</p>
        </div>

        <div className="profile-details">
          <div className="profile-detail-item">
            <AtSign size={16} className="profile-detail-icon" />
            <span className="profile-detail-label">Username:</span>
            <span className="profile-detail-value">{profile.username}</span>
          </div>

          <div className="profile-detail-item">
            <Hash size={16} className="profile-detail-icon" />
            <span className="profile-detail-label">Discord ID:</span>
            <span className="profile-detail-value">{profile.discordId}</span>
          </div>

          <div className="profile-detail-item">
            <MapPin size={16} className="profile-detail-icon" />
            <span className="profile-detail-label">Location:</span>
            <span className="profile-detail-value">{profile.location}</span>
          </div>

          <div className="profile-detail-item">
            <Briefcase size={16} className="profile-detail-icon" />
            <span className="profile-detail-label">Role:</span>
            <span className="profile-detail-value">{profile.role}</span>
          </div>
        </div>

        {/* Discord Button - SVG يدوي */}
        <a 
          href={profile.discordServerUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className="profile-discord-btn"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
          </svg>
          Join Discord Server
        </a>

        {/* YouTube Button - SVG يدوي */}
        <a 
          href={profile.youtubeUrl} 
          target="_blank" 
          rel="noopener noreferrer"
          className="profile-youtube-btn"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
            <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.376.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.376-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
          </svg>
          Subscribe on YouTube
        </a>
      </motion.div>
    </section>
  );
};

export default Profile; 