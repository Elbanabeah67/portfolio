import React from 'react';
import { motion } from 'framer-motion';
import { portfolioData } from '../data/portfolioData';

const Skills = ({ t }) => {
  const { skills } = portfolioData;

  // استخدام Simple Icons CDN مع ألوان أصلية
  const getSkillIcon = (name) => {
    switch (name.toLowerCase()) {
      case 'node.js':
        return (
          <img 
            src="https://cdn.simpleicons.org/nodedotjs/339933"
            width="32"
            height="32"
            alt="Node.js"
            style={{ filter: 'none' }}
          />
        );
      case 'python':
        return (
          <img 
            src="https://cdn.simpleicons.org/python/3776AB"
            width="32"
            height="32"
            alt="Python"
            style={{ filter: 'none' }}
          />
        );
      case 'html5 & css3':
        return (
          <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
            <img 
              src="https://cdn.simpleicons.org/html5/E44D26"
              width="32"
              height="32"
              alt="HTML5"
              style={{ filter: 'none' }}
            />
            <img 
              src="https://cdn.simpleicons.org/css3/2965F1"
              width="32"
              height="32"
              alt="CSS3"
              style={{ filter: 'none' }}
            />
          </div>
        );
      case 'javascript (es6+)':
        return (
          <img 
            src="https://cdn.simpleicons.org/javascript/F7DF1E"
            width="32"
            height="32"
            alt="JavaScript"
            style={{ filter: 'none' }}
          />
        );
      case 'react':
        return (
          <img 
            src="https://cdn.simpleicons.org/react/61DAFB"
            width="32"
            height="32"
            alt="React"
            style={{ filter: 'none' }}
          />
        );
      case 'git & workflow':
        return (
          <img 
            src="https://cdn.simpleicons.org/git/F05033"
            width="32"
            height="32"
            alt="Git"
            style={{ filter: 'none' }}
          />
        );
      default:
        return (
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
            <circle cx="16" cy="16" r="14" fill="#6366f1" opacity="0.8"/>
            <path d="M16 8V16L20 20" stroke="#FFFFFF" strokeWidth="2" fill="none"/>
            <circle cx="16" cy="16" r="1.5" fill="#FFFFFF"/>
          </svg>
        );
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const cardVariants = {
    hidden: { opacity: 0, scale: 0.9, y: 20 },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] }
    }
  };

  return (
    <section id="skills" className="skills-section">
      <motion.h2 
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="section-title"
      >
        {t.skills.title}
      </motion.h2>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        className="skills-grid"
      >
        {skills.map((skill, index) => (
          <motion.div 
            key={index}
            variants={cardVariants}
            className="skill-card glass-panel"
            whileHover={{ y: -8, transition: { duration: 0.2 } }}
          >
            <div className="skill-card-header">
              <div className="skill-icon-wrapper" style={{ background: 'transparent', border: 'none' }}>
                {getSkillIcon(skill.name)}
              </div>
              <h3 className="skill-name">{skill.name}</h3>
            </div>
            
            <p className="skill-description">{skill.description}</p>
            
            <div className="skill-progress-container">
              <div className="skill-progress-info">
                <span className="skill-level-text">
                  {t.lang === 'ar' ? 'الكفاءة البرمجية' : 'Proficiency'}
                </span>
                <span className="skill-percentage">{skill.level}%</span>
              </div>
              <div className="skill-bar-bg">
                <motion.div 
                  className="skill-bar-fill"
                  initial={{ width: 0 }}
                  whileInView={{ width: `${skill.level}%` }}
                  viewport={{ once: true }}
                  transition={{ duration: 1, delay: 0.2, ease: "easeOut" }}
                />
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      <div className="marquee-container">
        <div className="marquee-row animate-left">
          <div className="marquee-content">
            {t.skills.tickerRow1.map((item, idx) => (
              <span key={idx}>{item} &mdash; </span>
            ))}
          </div>
        </div>
        <div className="marquee-row animate-right">
          <div className="marquee-content">
            {t.skills.tickerRow2.map((item, idx) => (
              <span key={idx}>{item} &mdash; </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;