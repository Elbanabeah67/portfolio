import React, { useEffect } from 'react';
import { motion } from 'framer-motion';

function Preloader({ finishLoading, t }) {
  useEffect(() => {
    
    document.body.style.overflow = 'hidden';
    
    const timer = setTimeout(() => {
      finishLoading();
    }, 1800);

    return () => {
      
      document.body.style.overflow = '';
      clearTimeout(timer);
    };
  }, [finishLoading]);

  
  const overlayVariants = {
    initial: {
      y: 0,
    },
    exit: {
      y: '-100vh',
      transition: {
        duration: 0.8,
        ease: [0.76, 0, 0.24, 1], 
      },
    },
  };

  const contentVariants = {
    initial: {
      opacity: 0,
      scale: 0.8,
      y: 20,
    },
    animate: {
      opacity: 1,
      scale: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.16, 1, 0.3, 1], 
      },
    },
    exit: {
      opacity: 0,
      scale: 0.95,
      y: -20,
      transition: {
        duration: 0.5,
        ease: [0.16, 1, 0.3, 1],
      },
    },
  };

  const lineVariants = {
    initial: { scaleX: 0 },
    animate: {
      scaleX: 1,
      transition: {
        delay: 0.4,
        duration: 1.0,
        ease: [0.16, 1, 0.3, 1],
      },
    },
  };

  return (
    <motion.div
      className="preloader-overlay"
      variants={overlayVariants}
      initial="initial"
      exit="exit"
    >
      <div className="flex flex-col items-center justify-center relative z-[10000]">
        <motion.div
          variants={contentVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          className="preloader-logo flex items-baseline select-none"
        >
          <span>Blacker</span>
          <span className="dot">.</span>
        </motion.div>

        
        <motion.div
          variants={lineVariants}
          initial="initial"
          animate="animate"
          className="w-12 h-[1px] bg-white/20 mt-4 origin-left"
        />

        <motion.p
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 0.4, y: 0 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          exit={{ opacity: 0, y: -10 }}
          className="text-xs uppercase tracking-[0.3em] text-white mt-4 font-mono font-medium"
        >
          {t.preloader.sub}
        </motion.p>
      </div>
    </motion.div>
  );
}

export default Preloader;
