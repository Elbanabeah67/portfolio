import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Crown, Medal } from 'lucide-react';

const Companies = () => {
  const companies = [
    {
      id: 1,
      name: "DevXStore",
      role: "OWNER SHIP",
      year: "2026",
      logo: "https://res.cloudinary.com/difucqa9h/image/upload/v1780942744/discord_images/di0iclqqw8wpwmebhfv0.png",
      badge: "Ownership",
      badgeIcon: <Crown size={16} />,
      desc: "Premium digital products & development services. DevXStore is your premier destination for high-quality digital products, ranging from custom bot development and web solutions to automation scripts and software tools.",
      tags: ["Digital Products", "Custom Bots", "Web Solutions", "Automation"],
      link: "https://discord.gg/wdgmuGUN7S"
    },
    {
      id: 2,
      name: "EnzoCord Code",
      role: "FOUNDER & CEO",
      year: "2025",
      logo: "https://res.cloudinary.com/difucqa9h/image/upload/v1780948651/discord_images/vjgfcf7pu0cfiio7ikrt.jpg",
      badge: "Founder & CEO",
      badgeIcon: <Medal size={16} />,
      desc: "Premium Discord bot development and coding solutions. EnzoCord Code specializes in creating high-performance Discord bots, automation tools, and custom coding solutions for communities and businesses.",
      tags: ["Discord Bots", "Coding Solutions", "Automation", "Community Tools"],
      link: "https://discord.gg/ec-s"
    }
  ];

  return (
    <section id="companies" className="companies-section">
      <motion.h2 
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="section-title"
      >
        MY COMPANIES
      </motion.h2>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="companies-container"
      >
        <p className="companies-subtitle">
          More than just a freelancer — I establish and lead technology companies dedicated to delivering comprehensive digital products at scale.
        </p>

        <div className="companies-grid">
          {companies.map((company) => (
            <div key={company.id} className="company-card glass-panel">
              <div className="company-image-wrapper">
                <img 
                  src={company.logo} 
                  alt={company.name}
                  className="company-image"
                  style={{ filter: 'none' }}
                  onError={(e) => {
                    e.target.src = "https://ui-avatars.com/api/?name=" + company.name.charAt(0) + "&background=6366f1&color=fff";
                  }}
                />
              </div>

              <div className={`company-badge ${company.id === 1 ? 'ownership-badge' : 'founder-badge'}`}>
                {company.badgeIcon}
                <span>{company.badge}</span>
              </div>

              <div className="company-header">
                <div>
                  <h3 className="company-name">{company.name}</h3>
                  <p className="company-role">{company.role}</p>
                </div>
                <div className="company-year">{company.year}</div>
              </div>
              
              <p className="company-desc">{company.desc}</p>
              
              <div className="company-tags">
                {company.tags.map((tag, idx) => (
                  <span key={idx} className="company-tag">{tag}</span>
                ))}
              </div>

              <a href={company.link} target="_blank" rel="noopener noreferrer" className="company-btn">
                Visit {company.name}
                <ExternalLink size={14} />
              </a>
            </div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default Companies;