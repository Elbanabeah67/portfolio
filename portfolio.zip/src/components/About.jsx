import React from 'react';
import { motion } from 'framer-motion';
import { Server, Layout, ToggleLeft, MapPin } from 'lucide-react';

const About = ({ t }) => {
  const bio = t.about;

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] }
    }
  };

  const getIcon = (title) => {
    switch (title.toLowerCase()) {
      case 'backend specialist':
      case 'متخصص في الأنظمة الخلفية':
        return <Server className="highlight-icon" size={24} />;
      case 'frontend detail':
      case 'دقة في الواجهات الأمامية':
        return <Layout className="highlight-icon" size={24} />;
      default:
        return <ToggleLeft className="highlight-icon" size={24} />;
    }
  };

  return (
    <section id="about" className="about-section">
      <motion.h2 
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="section-title"
      >
        {bio.title}
      </motion.h2>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: "-100px" }}
        className="about-grid"
      >
        
        <motion.div variants={itemVariants} className="about-bio-card glass-panel">
          <h3 className="about-greeting">{bio.greeting}</h3>
          <p className="about-summary">{bio.summary}</p>
          <div className="about-location">
            <MapPin size={18} className="location-icon" />
            <span>{bio.location} {t.contact.locationValue}</span>
          </div>
        </motion.div>

        
        <div className="about-highlights">
          {bio.highlights.map((highlight, index) => (
            <motion.div 
              key={index} 
              variants={itemVariants} 
              className="highlight-card glass-panel"
            >
              <div className="highlight-header">
                {getIcon(highlight.title)}
                <h4 className="highlight-title">{highlight.title}</h4>
              </div>
              <p className="highlight-desc">{highlight.desc}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  );
};

export default About;
