import React from 'react';
import { motion } from 'framer-motion';

const Stats = ({ t }) => {
  const statsData = t.stats.items;

  return (
    <section className="stats-section">
      <div className="stats-container">
        {statsData.map((stat, idx) => (
          <motion.div 
            key={idx}
            initial={{ opacity: 0, y: 25 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: idx * 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="stat-item"
          >
            <span className="stat-number">{stat.value}</span>
            <span className="stat-label">{stat.label}</span>
          </motion.div>
        ))}
      </div>
    </section>
  );
};

export default Stats;
