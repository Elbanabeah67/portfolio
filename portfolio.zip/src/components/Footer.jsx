import React from 'react';
import { ArrowUp } from 'lucide-react';

const Footer = ({ t }) => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <footer className="footer" style={{ direction: t.lang === 'ar' ? 'rtl' : 'ltr' }}>
      <div className="footer-container">
        <p className="footer-copy">
          &copy; {new Date().getFullYear()} <span className="gradient-text font-semibold">Blacker</span>. {t.footer.rights}
        </p>
        
        <button 
          onClick={scrollToTop} 
          className="scroll-top-btn" 
          aria-label="Scroll to top"
        >
          <ArrowUp size={18} />
        </button>
      </div>
    </footer>
  );
};

export default Footer;
