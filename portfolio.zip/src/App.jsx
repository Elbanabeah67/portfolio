import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Profile from './components/Profile';
import About from './components/About';
import Projects from './components/Projects';
import Stats from './components/Stats';
import Philosophy from './components/Philosophy';
import Skills from './components/Skills';
import Companies from './components/Companies';
import Faq from './components/Faq';
import Contact from './components/Contact';
import Feedback from './components/Feedback';
import Footer from './components/Footer';
import Preloader from './components/Preloader';
import { translations } from './data/translations';

function App() {
  const [isLoading, setIsLoading] = useState(true);
  
  const [lang, setLang] = useState(() => {
    return localStorage.getItem('Blacker-lang') || 'en';
  });

  const [theme, setTheme] = useState(() => {
    return localStorage.getItem('Blacker-theme') || 'dark';
  });

  useEffect(() => {
    localStorage.setItem('Blacker-lang', lang);
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  useEffect(() => {
    localStorage.setItem('Blacker-theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const toggleTheme = (selectedTheme) => {
    if (selectedTheme) {
      setTheme(selectedTheme);
    } else {
      setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
    }
  };

  const t = translations[lang] || translations.en;
  t.lang = lang;

  return (
    <>
      <AnimatePresence mode="wait">
        {isLoading && (
          <Preloader finishLoading={() => setIsLoading(false)} t={t} />
        )}
      </AnimatePresence>

      <div className="swiss-grid-overlay">
        <div className="grid-line"></div>
        <div className="grid-line"></div>
        <div className="grid-line"></div>
        <div className="grid-line"></div>
      </div>

      <Navbar 
        lang={lang} 
        setLang={setLang} 
        theme={theme} 
        toggleTheme={toggleTheme} 
        t={t} 
      />
      <main>
        <Hero t={t} />
        <Profile />
        <About t={t} />
        <Projects t={t} />
        <Stats t={t} />
        <Philosophy t={t} />
        <Skills t={t} />
        <Companies />
        <Faq t={t} />
        <Contact t={t} />
        <Feedback />
      </main>
      <Footer t={t} />
    </>
  );
}

export default App;