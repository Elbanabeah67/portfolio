export const translations = {
  en: {
    nav: {
      home: "Home",
      profile: "Profile",
      about: "About",
      projects: "Projects",
      stats: "Stats",
      skills: "Skills",
      companies: "Companies",
      faq: "FAQ",
      contact: "Contact",
      settings: "Settings"
    },
    hero: {
      greeting: "Hello, I'm",
      name: "Blacker",
      title: "Full-Stack Developer & Engineer",
      skills: [
        "Backend Architecture",
        "Python Scrapers & Automation",
        "React Interactive Interfaces",
        "High-Performance Node.js APIs"
      ],
      tagline: "Building performant backend services and fluid user interfaces.",
      ctaWork: "View Work",
      ctaTalk: "Let's Talk"
    },
    about: {
      title: "About Me",
      greeting: "Hi, I'm Blacker.",
      summary: "I'm a full-stack developer who loves designing and building high-performance backend systems and engaging, interactive frontends. My main toolkit includes Node.js, Python, and modern web technologies. I focus on clean architecture, security, and smooth user experiences.",
      location: "Living in",
      highlights: [
        {
          title: "Backend Specialist",
          desc: "Experienced in building robust REST & GraphQL APIs, microservices, and web sockets using Node.js and Python."
        },
        {
          title: "Frontend Detail",
          desc: "Crafting fully responsive, interactive, and high-performance user interfaces using React, modern CSS, and animations."
        },
        {
          title: "Automation & Tools",
          desc: "Creating scripts, scrapers, and automation pipelines with Python to simplify workflows and parse complex data."
        }
      ]
    },
    projects: {
      title: "Featured Projects",
      subtitle: "A showcase of robust, containerized, and canvas-powered Discord application systems built to elevate community management.",
      ctaDownload: "Get / Invite",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Audio Stream"],
          desc: "A highly reliable bot that generates projects and codes, completely free to use."
        },
        {
          title: "Votes",
          tags: ["Python", "Astronomy API", "Node.js", "Cron Scheduling"],
          desc: "Automatically calculates and manages voting systems with precise analytics and real-time results."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Concurrency Control"],
          desc: "Advanced ticket management bot for support systems with isolated database storage and rapid ticket creation."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Years of Experience" },
        { value: "50k+", label: "Lines of Clean Code" },
        { value: "100%", label: "System Uptime Focus" }
      ]
    },
    philosophy: {
      quote: "Software engineering is not just about writing code; it is about crafting robust digital architecture that stands resilient under scale.",
      author: "Blacker's Philosophy"
    },
    skills: {
      title: "Skills & Workflow",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CLEAN CODE", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "SCALING", "GIT", "REST"]
    },
    faq: {
      title: "Frequently Asked Questions",
      items: [
        {
          q: "What is your preferred backend technology stack?",
          a: "I prefer working with Node.js (using Express or Fastify) for building highly concurrent and performant REST or GraphQL APIs, alongside Python (FastAPI or Django) for workflow automation and utility scripting."
        },
        {
          q: "Do you build full-stack web applications?",
          a: "Yes. I combine robust, high-performance backend systems and databases (Node.js & Python) with extremely fast, elegant, and interactive user interfaces using React and modern layout architectures."
        },
        {
          q: "How do you handle automation and data scraping?",
          a: "I develop highly reliable, custom Python automation pipelines designed to extract and structure data from complex web interfaces, helping businesses optimize operations and streamline manual workflows."
        },
        {
          q: "Are you available for remote work and contract projects?",
          a: "Yes, I am fully available for remote contract opportunities, technical consulting, and end-to-end systems development from conceptualization to deployment."
        }
      ]
    },
    contact: {
      title: "Get In Touch",
      subtitle: "Let's build something awesome",
      desc: "Whether you want to discuss a backend architecture using Node.js or Python, need dynamic layouts in React, or just want to connect, feel free to drop a message!",
      emailLabel: "Email Me",
      locationLabel: "Location",
      locationValue: "Egypt",
      nameField: "Name",
      namePlaceholder: "Enter your name",
      emailField: "Email",
      emailPlaceholder: "Enter your email",
      messageField: "Message",
      messagePlaceholder: "What would you like to discuss?",
      sendBtn: "Send Message",
      successTitle: "Message Sent Successfully!",
      successDesc: "Thank you for reaching out. I'll get back to you as soon as possible."
    },
    footer: {
      rights: "All rights reserved."
    },
    preloader: {
      sub: "CREATIVE DEVELOPER"
    },
    settings: {
      theme: "Theme",
      dark: "Dark",
      light: "Light",
      language: "Language",
      currentLanguage: "Current Language"
    }
  },
  ar: {
    nav: {
      home: "الرئيسية",
      profile: "الملف الشخصي",
      about: "من أنا",
      projects: "مشاريعي",
      stats: "إحصائيات",
      skills: "مهاراتي",
      companies: "الشركات",
      faq: "أسئلة شائعة",
      contact: "اتصل بي",
      settings: "الإعدادات"
    },
    hero: {
      greeting: "مرحباً، أنا",
      name: "بلاكر",
      title: "مطور خوادم ومهندس ويب متكامل",
      skills: [
        "معمارية الأنظمة الخلفية",
        "سكريبتات أتمتة وسحب بيانات بايثون",
        "واجهات تفاعلية باستخدام React",
        "واجهات برمجية سريعة بـ Node.js"
      ],
      tagline: "أبني خدمات خوادم فائقة الأداء وواجهات مستخدم تفاعلية انسيابية.",
      ctaWork: "عرض أعمالي",
      ctaTalk: "تحدث معي"
    },
    about: {
      title: "من أنا",
      greeting: "أهلاً، أنا بلاكر.",
      summary: "أنا مطور ويب متكامل (Full-Stack) شغوف بتصميم وبناء أنظمة خوادم عالية الأداء وواجهات أمامية تفاعلية جذابة. تتضمن أدواتي الأساسية Node.js وبايثون وتقنيات الويب الحديثة. أركز بشدة على المعمارية النظيفة، الأمان، والتجارب الرقمية السلسة.",
      location: "عايش في",
      highlights: [
        {
          title: "متخصص في الأنظمة الخلفية",
          desc: "خبرة واسعة في بناء واجهات برمجية REST و GraphQL قوية، وهندسة خوادم متناهية الصغر وقنوات اتصال ويب حية باستخدام Node.js وبايثون."
        },
        {
          title: "دقة في الواجهات الأمامية",
          desc: "تصميم واجهات مستخدم متجاوبة وتفاعلية بالكامل وسريعة للغاية بالاعتماد على مكتبة React وتقنيات CSS الحديثة والحركات الدقيقة."
        },
        {
          title: "أتمتة وأدوات مخصصة",
          desc: "برمجة سكريبتات أتمتة وقنوات سحب بيانات ذكية باستخدام لغة بايثون لتبسيط سير العمل والعمليات البرمجية المعقدة."
        }
      ]
    },
    projects: {
      title: "مشاريعي البرمجية",
      subtitle: "مجموعة من أنظمة تطبيقات ديسكورد المتطورة، المبنية بنظام الحاويات واللوحات الرسومية المخصصة لتسهيل وإثراء إدارة المجتمعات.",
      ctaDownload: "تحميل / دعوة",
      list: [
        {
          title: "Genprojects",
          tags: ["نود جي إس", "ديسكورد جي إس", "إف إف إم بي جي", "بث صوتي"],
          desc: "بوت موثوق يقوم بتوليد مشاريع وأكواد برمجية، مجاني بالكامل."
        },
        {
          title: "Votes",
          tags: ["بايثون", "واجهة فلكية", "نود جي إس", "جدولة زمنية"],
          desc: "يقوم بحساب وإدارة أنظمة التصويت تلقائياً مع تحليلات دقيقة ونتائج فورية."
        },
        {
          title: "Ticket",
          tags: ["دوكر", "مونغو دي بي", "نود جي إس", "إدارة عمليات"],
          desc: "بوت تذاكر دعم فني متطور يعتمد على حاويات دوكر المعزولة وقنوات تخزين بيانات مستقلة."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "سنوات خبرة برمجية" },
        { value: "50k+", label: "سطر كود نظيف وموثق" },
        { value: "100%", label: "استقرار الخوادم والأنظمة" }
      ]
    },
    philosophy: {
      quote: "هندسة البرمجيات ليست مجرد كتابة أكواد؛ بل هي فن بناء معمارية رقمية متينة تصمد بمرونة وكفاءة أمام أضخم معدلات التزايد والتشغيل.",
      author: "بلاكر - المهندس"
    },
    skills: {
      title: "مهاراتي وسير العمل",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CLEAN CODE", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "SCALING", "GIT", "REST"]
    },
    faq: {
      title: "الأسئلة الشائعة",
      items: [
        {
          q: "ما هي بيئة عمل الخوادم (Backend) الأساسية التي تفضلها؟",
          a: "أفضل العمل ببيئة Node.js (باستخدام Express أو Fastify) لبناء واجهات برمجية APIs عالية التزامن والأداء، بالإضافة إلى لغة Python (FastAPI أو Django) لأتمتة العمليات وبناء السكريبتات المتقدمة."
        },
        {
          q: "هل تقوم بتطوير تطبيقات الويب بالكامل (Full-Stack)؟",
          a: "نعم، أربط خوادم وقواعد البيانات المتينة (Node.js & Python) بواجهات أمامية تفاعلية وسريعة للغاية تعتمد على مكتبة React وتقنيات CSS الحديثة."
        },
        {
          q: "كيف تتعامل مع مهام الأتمتة وسحب البيانات (Data Scraping)؟",
          a: "أبني سكريبتات أتمتة قوية وموثوقة بلغة Python، مصممة لسحب وتحليل البيانات الضخمة والمعقدة، مع تهيئتها لتبسيط مهام وسير العمل للشركات."
        },
        {
          q: "هل أنت متاح للعمل الحر والمشاريع عن بعد؟",
          a: "نعم، أنا متاح للعمل عن بعد بالكامل للمشاريع التعاقدية، الاستشارات التقنية، وتطوير الأنظمة من البداية حتى إطلاقها بنجاح."
        }
      ]
    },
    contact: {
      title: "اتصل بي",
      subtitle: "دعنا نبني شيئاً مذهلاً",
      desc: "سواء كنت ترغب في مناقشة معمارية الخوادم باستخدام نود جي إس أو بايثون، أو كنت تحتاج لواجهات تفاعلية متطورة في رياكت، أو فقط ترغب في التواصل، يسعدني دائماً تواصلك معي!",
      emailLabel: "بريدي الإلكتروني",
      locationLabel: "الموقع الجغرافي",
      locationValue: "مصر",
      nameField: "الاسم",
      namePlaceholder: "أدخل اسمك الكريم",
      emailField: "البريد الإلكتروني",
      emailPlaceholder: "أدخل بريدك الإلكتروني",
      messageField: "الرسالة",
      messagePlaceholder: "ما الذي تود مناقشته معي؟",
      sendBtn: "إرسال الرسالة",
      successTitle: "تم إرسال رسالتك بنجاح!",
      successDesc: "شكراً لتواصلك معي. سأقوم بالرد عليك في أقرب وقت ممكن."
    },
    footer: {
      rights: "جميع الحقوق محفوظة."
    },
    preloader: {
      sub: "مطور ويب مبدع"
    },
    settings: {
      theme: "المظهر",
      dark: "داكن",
      light: "فاتح",
      language: "اللغة",
      currentLanguage: "اللغة الحالية"
    }
  },
  fr: {
    nav: {
      home: "Accueil",
      profile: "Profil",
      about: "À propos",
      projects: "Projets",
      stats: "Statistiques",
      skills: "Compétences",
      companies: "Entreprises",
      faq: "FAQ",
      contact: "Contact",
      settings: "Paramètres"
    },
    hero: {
      greeting: "Bonjour, je suis",
      name: "Blacker",
      title: "Développeur Full-Stack & Ingénieur",
      skills: [
        "Architecture Backend",
        "Scrapers Python & Automatisation",
        "Interfaces React Interactives",
        "APIs Node.js Hautes Performances"
      ],
      tagline: "Je construis des services backend performants et des interfaces utilisateur fluides.",
      ctaWork: "Voir le travail",
      ctaTalk: "Parlons-en"
    },
    about: {
      title: "À propos de moi",
      greeting: "Bonjour, je suis Blacker.",
      summary: "Je suis un développeur full-stack passionné par la conception et la construction de systèmes backend hautes performances et de frontaux interactifs attrayants. Ma boîte à outils principale comprend Node.js, Python et les technologies web modernes. Je me concentre sur une architecture propre, la sécurité et des expériences utilisateur fluides.",
      location: "Habite en",
      highlights: [
        {
          title: "Spécialiste Backend",
          desc: "Expérimenté dans la construction d'APIs REST et GraphQL robustes, de microservices et de websockets utilisant Node.js et Python."
        },
        {
          title: "Précision Frontend",
          desc: "Conception d'interfaces utilisateur entièrement réactives, interactives et hautes performances utilisant React, le CSS moderne et les animations."
        },
        {
          title: "Automatisation & Outils",
          desc: "Création de scripts, scrappers et pipelines d'automatisation avec Python pour simplifier les flux de travail et analyser des données complexes."
        }
      ]
    },
    projects: {
      title: "Projets Phares",
      subtitle: "Une vitrine de systèmes d'applications Discord robustes, conteneurisés et alimentés par des toiles conçus pour améliorer la gestion communautaire.",
      ctaDownload: "Obtenir / Inviter",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Flux Audio"],
          desc: "Un bot très fiable qui génère des projets et des codes, entièrement gratuit."
        },
        {
          title: "Votes",
          tags: ["Python", "API Astronomie", "Node.js", "Planification Cron"],
          desc: "Calcule et gère automatiquement les systèmes de vote avec des analyses précises et des résultats en temps réel."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Contrôle de Concurrence"],
          desc: "Bot de gestion de tickets avancé pour les systèmes de support avec stockage de base de données isolé et création rapide de tickets."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Années d'expérience" },
        { value: "50k+", label: "Lignes de code propre" },
        { value: "100%", label: "Focus sur la disponibilité système" }
      ]
    },
    philosophy: {
      quote: "L'ingénierie logicielle ne consiste pas seulement à écrire du code ; il s'agit de créer une architecture numérique robuste qui résiste à l'échelle.",
      author: "Philosophie de Blacker"
    },
    skills: {
      title: "Compétences & Flux de Travail",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CODE PROPRE", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "MISE À L'ÉCHELLE", "GIT", "REST"]
    },
    faq: {
      title: "Questions Fréquemment Posées",
      items: [
        {
          q: "Quelle est votre pile technologique backend préférée ?",
          a: "Je préfère travailler avec Node.js (en utilisant Express ou Fastify) pour construire des APIs REST ou GraphQL très concurrentes et performantes, ainsi que Python (FastAPI ou Django) pour l'automatisation des flux de travail et les scripts utilitaires."
        },
        {
          q: "Construisez-vous des applications web full-stack ?",
          a: "Oui. Je combine des systèmes backend robustes et hautes performances avec des bases de données (Node.js et Python) avec des interfaces utilisateur extrêmement rapides, élégantes et interactives utilisant React et des architectures de mise en page modernes."
        },
        {
          q: "Comment gérez-vous l'automatisation et le scraping de données ?",
          a: "Je développe des pipelines d'automatisation Python personnalisés, très fiables, conçus pour extraire et structurer des données à partir d'interfaces web complexes, aidant les entreprises à optimiser leurs opérations et à rationaliser les flux de travail manuels."
        },
        {
          q: "Êtes-vous disponible pour le travail à distance et les projets contractuels ?",
          a: "Oui, je suis entièrement disponible pour des opportunités contractuelles à distance, des conseils techniques et le développement de systèmes de bout en bout, de la conceptualisation au déploiement."
        }
      ]
    },
    contact: {
      title: "Contactez-moi",
      subtitle: "Construisons quelque chose d'incroyable",
      desc: "Que vous souhaitiez discuter d'une architecture backend utilisant Node.js ou Python, avoir besoin de mises en page dynamiques dans React, ou simplement vouloir vous connecter, n'hésitez pas à envoyer un message !",
      emailLabel: "M'envoyer un email",
      locationLabel: "Emplacement",
      locationValue: "Égypte",
      nameField: "Nom",
      namePlaceholder: "Entrez votre nom",
      emailField: "Email",
      emailPlaceholder: "Entrez votre email",
      messageField: "Message",
      messagePlaceholder: "De quoi souhaitez-vous discuter ?",
      sendBtn: "Envoyer le message",
      successTitle: "Message envoyé avec succès !",
      successDesc: "Merci de nous avoir contactés. Je vous répondrai dès que possible."
    },
    footer: {
      rights: "Tous droits réservés."
    },
    preloader: {
      sub: "DÉVELOPPEUR CRÉATIF"
    },
    settings: {
      theme: "Thème",
      dark: "Sombre",
      light: "Clair",
      language: "Langue",
      currentLanguage: "Langue actuelle"
    }
  },
  es: {
    nav: {
      home: "Inicio",
      profile: "Perfil",
      about: "Acerca de",
      projects: "Proyectos",
      stats: "Estadísticas",
      skills: "Habilidades",
      companies: "Empresas",
      faq: "Preguntas Frecuentes",
      contact: "Contacto",
      settings: "Configuración"
    },
    hero: {
      greeting: "Hola, soy",
      name: "Blacker",
      title: "Desarrollador Full-Stack e Ingeniero",
      skills: [
        "Arquitectura Backend",
        "Scrapers Python y Automatización",
        "Interfaces React Interactivas",
        "APIs Node.js de Alto Rendimiento"
      ],
      tagline: "Construyendo servicios backend de alto rendimiento e interfaces de usuario fluidas.",
      ctaWork: "Ver Trabajo",
      ctaTalk: "Hablemos"
    },
    about: {
      title: "Acerca de Mí",
      greeting: "Hola, soy Blacker.",
      summary: "Soy un desarrollador full-stack apasionado por diseñar y construir sistemas backend de alto rendimiento y frontends interactivos atractivos. Mi conjunto de herramientas principal incluye Node.js, Python y tecnologías web modernas. Me enfoco en arquitectura limpia, seguridad y experiencias de usuario fluidas.",
      location: "Viviendo en",
      highlights: [
        {
          title: "Especialista Backend",
          desc: "Experiencia en la construcción de APIs REST y GraphQL robustas, microservicios y websockets usando Node.js y Python."
        },
        {
          title: "Precisión Frontend",
          desc: "Diseño de interfaces de usuario completamente responsivas, interactivas y de alto rendimiento usando React, CSS moderno y animaciones."
        },
        {
          title: "Automatización y Herramientas",
          desc: "Creación de scripts, scrappers y pipelines de automatización con Python para simplificar flujos de trabajo y analizar datos complejos."
        }
      ]
    },
    projects: {
      title: "Proyectos Destacados",
      subtitle: "Una muestra de sistemas de aplicaciones Discord robustos, contenerizados y basados en canvas diseñados para elevar la gestión comunitaria.",
      ctaDownload: "Obtener / Invitar",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Flujo de Audio"],
          desc: "Un bot altamente confiable que genera proyectos y códigos, completamente gratuito."
        },
        {
          title: "Votes",
          tags: ["Python", "API Astronomía", "Node.js", "Programación Cron"],
          desc: "Calcula y gestiona automáticamente sistemas de votación con análisis precisos y resultados en tiempo real."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Control de Concurrencia"],
          desc: "Bot avanzado de gestión de tickets para sistemas de soporte con almacenamiento aislado en base de datos y creación rápida de tickets."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Años de Experiencia" },
        { value: "50k+", label: "Líneas de Código Limpio" },
        { value: "100%", label: "Enfoque en Disponibilidad del Sistema" }
      ]
    },
    philosophy: {
      quote: "La ingeniería de software no se trata solo de escribir código; se trata de crear una arquitectura digital robusta que resista a escala.",
      author: "Filosofía de Blacker"
    },
    skills: {
      title: "Habilidades y Flujo de Trabajo",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CÓDIGO LIMPIO", "MONGODB", "POSTGRESQL", "DOCKER", "RENDIMIENTO", "ESCALABILIDAD", "GIT", "REST"]
    },
    faq: {
      title: "Preguntas Frecuentes",
      items: [
        {
          q: "¿Cuál es tu pila tecnológica backend preferida?",
          a: "Prefiero trabajar con Node.js (usando Express o Fastify) para construir APIs REST o GraphQL altamente concurrentes y de alto rendimiento, junto con Python (FastAPI o Django) para automatización de flujos de trabajo y scripts utilitarios."
        },
        {
          q: "¿Construyes aplicaciones web full-stack?",
          a: "Sí. Combino sistemas backend robustos y de alto rendimiento con bases de datos (Node.js y Python) con interfaces de usuario extremadamente rápidas, elegantes e interactivas usando React y arquitecturas de diseño modernas."
        },
        {
          q: "¿Cómo manejas la automatización y el scraping de datos?",
          a: "Desarrollo pipelines de automatización Python personalizados, altamente confiables, diseñados para extraer y estructurar datos de interfaces web complejas, ayudando a las empresas a optimizar operaciones y racionalizar flujos de trabajo manuales."
        },
        {
          q: "¿Estás disponible para trabajo remoto y proyectos por contrato?",
          a: "Sí, estoy completamente disponible para oportunidades contractuales remotas, consultoría técnica y desarrollo de sistemas de extremo a extremo desde la conceptualización hasta el despliegue."
        }
      ]
    },
    contact: {
      title: "Ponte en Contacto",
      subtitle: "Construyamos algo increíble",
      desc: "Ya sea que quieras discutir una arquitectura backend usando Node.js o Python, necesites diseños dinámicos en React, o simplemente quieras conectar, ¡no dudes en enviar un mensaje!",
      emailLabel: "Enviar Correo",
      locationLabel: "Ubicación",
      locationValue: "Egipto",
      nameField: "Nombre",
      namePlaceholder: "Ingresa tu nombre",
      emailField: "Correo",
      emailPlaceholder: "Ingresa tu correo",
      messageField: "Mensaje",
      messagePlaceholder: "¿De qué te gustaría hablar?",
      sendBtn: "Enviar Mensaje",
      successTitle: "¡Mensaje Enviado con Éxito!",
      successDesc: "Gracias por contactarme. Te responderé lo antes posible."
    },
    footer: {
      rights: "Todos los derechos reservados."
    },
    preloader: {
      sub: "DESARROLLADOR CREATIVO"
    },
    settings: {
      theme: "Tema",
      dark: "Oscuro",
      light: "Claro",
      language: "Idioma",
      currentLanguage: "Idioma actual"
    }
  },
  de: {
    nav: {
      home: "Startseite",
      profile: "Profil",
      about: "Über mich",
      projects: "Projekte",
      stats: "Statistiken",
      skills: "Fähigkeiten",
      companies: "Unternehmen",
      faq: "FAQ",
      contact: "Kontakt",
      settings: "Einstellungen"
    },
    hero: {
      greeting: "Hallo, ich bin",
      name: "Blacker",
      title: "Full-Stack Entwickler & Ingenieur",
      skills: [
        "Backend-Architektur",
        "Python Scraper & Automatisierung",
        "React Interaktive Oberflächen",
        "Hochleistungs-Node.js-APIs"
      ],
      tagline: "Ich baue leistungsstarke Backend-Dienste und flüssige Benutzeroberflächen.",
      ctaWork: "Arbeit ansehen",
      ctaTalk: "Lass uns reden"
    },
    about: {
      title: "Über mich",
      greeting: "Hallo, ich bin Blacker.",
      summary: "Ich bin ein Full-Stack-Entwickler, der leidenschaftlich gerne leistungsstarke Backend-Systeme und ansprechende, interaktive Frontends entwirft und baut. Meine Hauptwerkzeuge sind Node.js, Python und moderne Webtechnologien. Ich konzentriere mich auf saubere Architektur, Sicherheit und flüssige Benutzererlebnisse.",
      location: "Lebt in",
      highlights: [
        {
          title: "Backend-Spezialist",
          desc: "Erfahren in der Entwicklung robuster REST- und GraphQL-APIs, Microservices und WebSockets mit Node.js und Python."
        },
        {
          title: "Frontend-Detail",
          desc: "Gestaltung vollständig responsiver, interaktiver und leistungsstarker Benutzeroberflächen mit React, modernem CSS und Animationen."
        },
        {
          title: "Automatisierung & Tools",
          desc: "Erstellung von Skripten, Scrapern und Automatisierungspipelines mit Python zur Vereinfachung von Arbeitsabläufen und Analyse komplexer Daten."
        }
      ]
    },
    projects: {
      title: "Ausgewählte Projekte",
      subtitle: "Eine Auswahl robuster, containerisierter und Canvas-basierter Discord-Anwendungssysteme zur Verbesserung der Community-Verwaltung.",
      ctaDownload: "Holen / Einladen",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Audio-Stream"],
          desc: "Ein äußerst zuverlässiger Bot, der Projekte und Codes generiert, völlig kostenlos."
        },
        {
          title: "Votes",
          tags: ["Python", "Astronomie-API", "Node.js", "Cron-Planung"],
          desc: "Berechnet und verwaltet automatisch Wahlsysteme mit präzisen Analysen und Echtzeitergebnissen."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Parallelitätskontrolle"],
          desc: "Fortschrittlicher Ticket-Management-Bot für Support-Systeme mit isolierter Datenbankspeicherung und schneller Ticket-Erstellung."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Jahre Erfahrung" },
        { value: "50k+", label: "Zeilen sauberen Codes" },
        { value: "100%", label: "Fokus auf Systemverfügbarkeit" }
      ]
    },
    philosophy: {
      quote: "Software-Engineering bedeutet nicht nur Code schreiben; es geht darum, robuste digitale Architekturen zu schaffen, die unter Skalierung widerstandsfähig bleiben.",
      author: "Blackers Philosophie"
    },
    skills: {
      title: "Fähigkeiten & Arbeitsablauf",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["SAUBERER CODE", "MONGODB", "POSTGRESQL", "DOCKER", "LEISTUNG", "SKALIERUNG", "GIT", "REST"]
    },
    faq: {
      title: "Häufig gestellte Fragen",
      items: [
        {
          q: "Was ist Ihr bevorzugter Backend-Technologie-Stack?",
          a: "Ich arbeite bevorzugt mit Node.js (mit Express oder Fastify) für hochkonkurrierende und leistungsstarke REST- oder GraphQL-APIs, zusammen mit Python (FastAPI oder Django) für Workflow-Automatisierung und Utility-Scripting."
        },
        {
          q: "Bauen Sie Full-Stack-Webanwendungen?",
          a: "Ja. Ich kombiniere robuste, leistungsstarke Backend-Systeme und Datenbanken (Node.js & Python) mit extrem schnellen, eleganten und interaktiven Benutzeroberflächen mit React und modernen Layout-Architekturen."
        },
        {
          q: "Wie handhaben Sie Automatisierung und Data Scraping?",
          a: "Ich entwickle hochzuverlässige, benutzerdefinierte Python-Automatisierungspipelines, die darauf ausgelegt sind, Daten aus komplexen Weboberflächen zu extrahieren und zu strukturieren, um Unternehmen bei der Optimierung von Abläufen und der Rationalisierung manueller Arbeitsabläufe zu helfen."
        },
        {
          q: "Sind Sie für Remote-Arbeit und Vertragsprojekte verfügbar?",
          a: "Ja, ich bin vollständig verfügbar für Remote-Vertragsmöglichkeiten, technische Beratung und End-to-End-Systementwicklung von der Konzeption bis zur Bereitstellung."
        }
      ]
    },
    contact: {
      title: "Kontaktieren Sie mich",
      subtitle: "Lassen Sie uns etwas Großartiges bauen",
      desc: "Ob Sie eine Backend-Architektur mit Node.js oder Python besprechen möchten, dynamische Layouts in React benötigen oder einfach nur verbinden möchten, zögern Sie nicht, eine Nachricht zu senden!",
      emailLabel: "E-Mail senden",
      locationLabel: "Standort",
      locationValue: "Ägypten",
      nameField: "Name",
      namePlaceholder: "Geben Sie Ihren Namen ein",
      emailField: "E-Mail",
      emailPlaceholder: "Geben Sie Ihre E-Mail ein",
      messageField: "Nachricht",
      messagePlaceholder: "Was möchten Sie besprechen?",
      sendBtn: "Nachricht senden",
      successTitle: "Nachricht erfolgreich gesendet!",
      successDesc: "Vielen Dank für Ihre Kontaktaufnahme. Ich werde mich so schnell wie möglich bei Ihnen melden."
    },
    footer: {
      rights: "Alle Rechte vorbehalten."
    },
    preloader: {
      sub: "KREATIVER ENTWICKLER"
    },
    settings: {
      theme: "Design",
      dark: "Dunkel",
      light: "Hell",
      language: "Sprache",
      currentLanguage: "Aktuelle Sprache"
    }
  },
  it: {
    nav: {
      home: "Home",
      profile: "Profilo",
      about: "Chi sono",
      projects: "Progetti",
      stats: "Statistiche",
      skills: "Competenze",
      companies: "Aziende",
      faq: "FAQ",
      contact: "Contatti",
      settings: "Impostazioni"
    },
    hero: {
      greeting: "Ciao, sono",
      name: "Blacker",
      title: "Sviluppatore Full-Stack & Ingegnere",
      skills: [
        "Architettura Backend",
        "Scraper Python & Automazione",
        "Interfacce React Interattive",
        "API Node.js ad Alte Prestazioni"
      ],
      tagline: "Costruisco servizi backend performanti e interfacce utente fluide.",
      ctaWork: "Vedi Lavori",
      ctaTalk: "Parliamo"
    },
    about: {
      title: "Chi sono",
      greeting: "Ciao, sono Blacker.",
      summary: "Sono uno sviluppatore full-stack appassionato di progettazione e costruzione di sistemi backend ad alte prestazioni e frontend interattivi coinvolgenti. Il mio kit principale include Node.js, Python e tecnologie web moderne. Mi concentro su architettura pulita, sicurezza e esperienze utente fluide.",
      location: "Vivo in",
      highlights: [
        {
          title: "Specialista Backend",
          desc: "Esperto nella costruzione di API REST e GraphQL robuste, microservizi e websocket utilizzando Node.js e Python."
        },
        {
          title: "Dettaglio Frontend",
          desc: "Creazione di interfacce utente completamente reattive, interattive e ad alte prestazioni utilizzando React, CSS moderno e animazioni."
        },
        {
          title: "Automazione & Strumenti",
          desc: "Creazione di script, scraper e pipeline di automazione con Python per semplificare i flussi di lavoro e analizzare dati complessi."
        }
      ]
    },
    projects: {
      title: "Progetti in Evidenza",
      subtitle: "Una vetrina di sistemi applicativi Discord robusti, containerizzati e basati su canvas progettati per migliorare la gestione della comunità.",
      ctaDownload: "Ottieni / Invita",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Stream Audio"],
          desc: "Un bot altamente affidabile che genera progetti e codici, completamente gratuito."
        },
        {
          title: "Votes",
          tags: ["Python", "API Astronomia", "Node.js", "Pianificazione Cron"],
          desc: "Calcola e gestisce automaticamente i sistemi di voto con analisi precise e risultati in tempo reale."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Controllo Concorrenza"],
          desc: "Bot avanzato di gestione ticket per sistemi di supporto con archiviazione database isolata e creazione rapida di ticket."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Anni di Esperienza" },
        { value: "50k+", label: "Righe di Codice Pulito" },
        { value: "100%", label: "Focus sull'Uptime del Sistema" }
      ]
    },
    philosophy: {
      quote: "L'ingegneria del software non riguarda solo la scrittura di codice; si tratta di creare un'architettura digitale robusta che rimanga resiliente sotto scala.",
      author: "Filosofia di Blacker"
    },
    skills: {
      title: "Competenze & Flusso di Lavoro",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CODICE PULITO", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "SCALABILITÀ", "GIT", "REST"]
    },
    faq: {
      title: "Domande Frequenti",
      items: [
        {
          q: "Qual è il tuo stack tecnologico backend preferito?",
          a: "Preferisco lavorare con Node.js (usando Express o Fastify) per costruire API REST o GraphQL altamente concorrenti e performanti, insieme a Python (FastAPI o Django) per l'automazione dei flussi di lavoro e lo scripting utility."
        },
        {
          q: "Costruisci applicazioni web full-stack?",
          a: "Sì. Combino sistemi backend robusti e ad alte prestazioni con database (Node.js e Python) con interfacce utente estremamente veloci, eleganti e interattive utilizzando React e architetture di layout moderne."
        },
        {
          q: "Come gestisci l'automazione e il data scraping?",
          a: "Sviluppo pipeline di automazione Python personalizzate e altamente affidabili, progettate per estrarre e strutturare dati da interfacce web complesse, aiutando le aziende a ottimizzare le operazioni e semplificare i flussi di lavoro manuali."
        },
        {
          q: "Sei disponibile per lavoro remoto e progetti in contratto?",
          a: "Sì, sono completamente disponibile per opportunità di contratto remoto, consulenza tecnica e sviluppo end-to-end di sistemi dalla concettualizzazione al deployment."
        }
      ]
    },
    contact: {
      title: "Contattami",
      subtitle: "Costruiamo qualcosa di fantastico",
      desc: "Che tu voglia discutere un'architettura backend utilizzando Node.js o Python, necessiti di layout dinamici in React, o semplicemente desideri connetterti, non esitare a inviare un messaggio!",
      emailLabel: "Invia Email",
      locationLabel: "Posizione",
      locationValue: "Egitto",
      nameField: "Nome",
      namePlaceholder: "Inserisci il tuo nome",
      emailField: "Email",
      emailPlaceholder: "Inserisci la tua email",
      messageField: "Messaggio",
      messagePlaceholder: "Di cosa vorresti parlare?",
      sendBtn: "Invia Messaggio",
      successTitle: "Messaggio Inviato con Successo!",
      successDesc: "Grazie per avermi contattato. Ti risponderò al più presto possibile."
    },
    footer: {
      rights: "Tutti i diritti riservati."
    },
    preloader: {
      sub: "SVILUPPATORE CREATIVO"
    },
    settings: {
      theme: "Tema",
      dark: "Scuro",
      light: "Chiaro",
      language: "Lingua",
      currentLanguage: "Lingua attuale"
    }
  },
  pt: {
    nav: {
      home: "Início",
      profile: "Perfil",
      about: "Sobre",
      projects: "Projetos",
      stats: "Estatísticas",
      skills: "Habilidades",
      companies: "Empresas",
      faq: "FAQ",
      contact: "Contato",
      settings: "Configurações"
    },
    hero: {
      greeting: "Olá, sou",
      name: "Blacker",
      title: "Desenvolvedor Full-Stack & Engenheiro",
      skills: [
        "Arquitetura Backend",
        "Scrapers Python & Automação",
        "Interfaces React Interativas",
        "APIs Node.js de Alto Desempenho"
      ],
      tagline: "Construindo serviços backend de alto desempenho e interfaces de usuário fluidas.",
      ctaWork: "Ver Trabalho",
      ctaTalk: "Vamos Conversar"
    },
    about: {
      title: "Sobre Mim",
      greeting: "Olá, sou Blacker.",
      summary: "Sou um desenvolvedor full-stack apaixonado por projetar e construir sistemas backend de alto desempenho e frontends interativos envolventes. Meu kit de ferramentas principal inclui Node.js, Python e tecnologias web modernas. Foco em arquitetura limpa, segurança e experiências de usuário fluidas.",
      location: "Morando em",
      highlights: [
        {
          title: "Especialista Backend",
          desc: "Experiente na construção de APIs REST e GraphQL robustas, microsserviços e websockets usando Node.js e Python."
        },
        {
          title: "Detalhe Frontend",
          desc: "Criação de interfaces de usuário totalmente responsivas, interativas e de alto desempenho usando React, CSS moderno e animações."
        },
        {
          title: "Automação & Ferramentas",
          desc: "Criação de scripts, scrapers e pipelines de automação com Python para simplificar fluxos de trabalho e analisar dados complexos."
        }
      ]
    },
    projects: {
      title: "Projetos em Destaque",
      subtitle: "Uma vitrine de sistemas de aplicativos Discord robustos, conteinerizados e baseados em canvas projetados para elevar o gerenciamento comunitário.",
      ctaDownload: "Obter / Convidar",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Stream de Áudio"],
          desc: "Um bot altamente confiável que gera projetos e códigos, completamente gratuito."
        },
        {
          title: "Votes",
          tags: ["Python", "API Astronomia", "Node.js", "Agendamento Cron"],
          desc: "Calcula e gerencia automaticamente sistemas de votação com análises precisas e resultados em tempo real."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Controle de Concorrência"],
          desc: "Bot avançado de gerenciamento de tickets para sistemas de suporte com armazenamento isolado em banco de dados e criação rápida de tickets."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Anos de Experiência" },
        { value: "50k+", label: "Linhas de Código Limpo" },
        { value: "100%", label: "Foco em Uptime do Sistema" }
      ]
    },
    philosophy: {
      quote: "A engenharia de software não é apenas sobre escrever código; é sobre criar uma arquitetura digital robusta que permanece resiliente sob escala.",
      author: "Filosofia de Blacker"
    },
    skills: {
      title: "Habilidades & Fluxo de Trabalho",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CÓDIGO LIMPO", "MONGODB", "POSTGRESQL", "DOCKER", "DESEMPENHO", "ESCALABILIDADE", "GIT", "REST"]
    },
    faq: {
      title: "Perguntas Frequentes",
      items: [
        {
          q: "Qual é a sua pilha tecnológica backend preferida?",
          a: "Prefiro trabalhar com Node.js (usando Express ou Fastify) para construir APIs REST ou GraphQL altamente concorrentes e performantes, juntamente com Python (FastAPI ou Django) para automação de fluxos de trabalho e scripts utilitários."
        },
        {
          q: "Você constrói aplicações web full-stack?",
          a: "Sim. Combino sistemas backend robustos e de alto desempenho com bancos de dados (Node.js e Python) com interfaces de usuário extremamente rápidas, elegantes e interativas usando React e arquiteturas de layout modernas."
        },
        {
          q: "Como você lida com automação e scraping de dados?",
          a: "Desenvolvo pipelines de automação Python personalizados e altamente confiáveis, projetados para extrair e estruturar dados de interfaces web complexas, ajudando empresas a otimizar operações e simplificar fluxos de trabalho manuais."
        },
        {
          q: "Você está disponível para trabalho remoto e projetos contratados?",
          a: "Sim, estou totalmente disponível para oportunidades de contrato remoto, consultoria técnica e desenvolvimento de sistemas end-to-end desde a conceituação até a implantação."
        }
      ]
    },
    contact: {
      title: "Entre em Contato",
      subtitle: "Vamos construir algo incrível",
      desc: "Se você deseja discutir uma arquitetura backend usando Node.js ou Python, precisa de layouts dinâmicos em React, ou apenas quer se conectar, fique à vontade para enviar uma mensagem!",
      emailLabel: "Enviar Email",
      locationLabel: "Localização",
      locationValue: "Egito",
      nameField: "Nome",
      namePlaceholder: "Digite seu nome",
      emailField: "Email",
      emailPlaceholder: "Digite seu email",
      messageField: "Mensagem",
      messagePlaceholder: "Sobre o que você gostaria de discutir?",
      sendBtn: "Enviar Mensagem",
      successTitle: "Mensagem Enviada com Sucesso!",
      successDesc: "Obrigado por entrar em contato. Responderei o mais rápido possível."
    },
    footer: {
      rights: "Todos os direitos reservados."
    },
    preloader: {
      sub: "DESENVOLVEDOR CRIATIVO"
    },
    settings: {
      theme: "Tema",
      dark: "Escuro",
      light: "Claro",
      language: "Idioma",
      currentLanguage: "Idioma atual"
    }
  },
  ru: {
    nav: {
      home: "Главная",
      profile: "Профиль",
      about: "Обо мне",
      projects: "Проекты",
      stats: "Статистика",
      skills: "Навыки",
      companies: "Компании",
      faq: "Вопросы",
      contact: "Контакты",
      settings: "Настройки"
    },
    hero: {
      greeting: "Привет, я",
      name: "Blacker",
      title: "Full-Stack Разработчик и Инженер",
      skills: [
        "Бэкенд Архитектура",
        "Python Парсеры и Автоматизация",
        "Интерактивные React Интерфейсы",
        "Высокопроизводительные Node.js API"
      ],
      tagline: "Создаю производительные бэкенд-сервисы и плавные пользовательские интерфейсы.",
      ctaWork: "Посмотреть Работы",
      ctaTalk: "Давайте Обсудим"
    },
    about: {
      title: "Обо мне",
      greeting: "Привет, я Blacker.",
      summary: "Я full-stack разработчик, увлеченный проектированием и созданием высокопроизводительных бэкенд-систем и интерактивных фронтендов. Мой основной инструментарий включает Node.js, Python и современные веб-технологии. Я сосредоточен на чистой архитектуре, безопасности и плавном пользовательском опыте.",
      location: "Проживаю в",
      highlights: [
        {
          title: "Специалист по Бэкенду",
          desc: "Опыт в создании надежных REST и GraphQL API, микросервисов и веб-сокетов с использованием Node.js и Python."
        },
        {
          title: "Детализация Фронтенда",
          desc: "Создание полностью адаптивных, интерактивных и высокопроизводительных пользовательских интерфейсов с использованием React, современного CSS и анимаций."
        },
        {
          title: "Автоматизация и Инструменты",
          desc: "Создание скриптов, парсеров и пайплайнов автоматизации на Python для упрощения рабочих процессов и анализа сложных данных."
        }
      ]
    },
    projects: {
      title: "Избранные Проекты",
      subtitle: "Демонстрация надежных, контейнеризированных систем приложений Discord, созданных для улучшения управления сообществами.",
      ctaDownload: "Получить / Пригласить",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Аудио Поток"],
          desc: "Высоконадежный бот, который генерирует проекты и коды, полностью бесплатный."
        },
        {
          title: "Votes",
          tags: ["Python", "Astronomy API", "Node.js", "Cron Планирование"],
          desc: "Автоматически рассчитывает и управляет системами голосования с точной аналитикой и результатами в реальном времени."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Управление Потоками"],
          desc: "Продвинутый бот управления тикетами для систем поддержки с изолированным хранением базы данных и быстрым созданием тикетов."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Лет Опыта" },
        { value: "50k+", label: "Строк Чистого Кода" },
        { value: "100%", label: "Фокус на Доступности Системы" }
      ]
    },
    philosophy: {
      quote: "Программная инженерия - это не просто написание кода; это создание надежной цифровой архитектуры, устойчивой к масштабированию.",
      author: "Философия Blacker"
    },
    skills: {
      title: "Навыки и Рабочий Процесс",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["ЧИСТЫЙ КОД", "MONGODB", "POSTGRESQL", "DOCKER", "ПРОИЗВОДИТЕЛЬНОСТЬ", "МАСШТАБИРОВАНИЕ", "GIT", "REST"]
    },
    faq: {
      title: "Часто Задаваемые Вопросы",
      items: [
        {
          q: "Какой стек бэкенд-технологий вы предпочитаете?",
          a: "Я предпочитаю работать с Node.js (используя Express или Fastify) для создания высококонкурентных и производительных REST или GraphQL API, а также с Python (FastAPI или Django) для автоматизации рабочих процессов и утилитарных скриптов."
        },
        {
          q: "Вы создаете full-stack веб-приложения?",
          a: "Да. Я сочетаю надежные, высокопроизводительные бэкенд-системы и базы данных (Node.js и Python) с чрезвычайно быстрыми, элегантными и интерактивными пользовательскими интерфейсами с использованием React и современных архитектур макетов."
        },
        {
          q: "Как вы обрабатываете автоматизацию и сбор данных?",
          a: "Я разрабатываю высоконадежные, настраиваемые пайплайны автоматизации на Python, предназначенные для извлечения и структурирования данных из сложных веб-интерфейсов, помогая бизнесу оптимизировать операции и упрощать ручные рабочие процессы."
        },
        {
          q: "Вы доступны для удаленной работы и контрактных проектов?",
          a: "Да, я полностью доступен для удаленных контрактных возможностей, технических консультаций и разработки систем от концепции до развертывания."
        }
      ]
    },
    contact: {
      title: "Свяжитесь со Мной",
      subtitle: "Давайте создадим что-то потрясающее",
      desc: "Будь то обсуждение бэкенд-архитектуры с использованием Node.js или Python, создание динамических макетов в React, или просто желание пообщаться, не стесняйтесь отправлять сообщение!",
      emailLabel: "Написать Email",
      locationLabel: "Местоположение",
      locationValue: "Египет",
      nameField: "Имя",
      namePlaceholder: "Введите ваше имя",
      emailField: "Email",
      emailPlaceholder: "Введите ваш email",
      messageField: "Сообщение",
      messagePlaceholder: "Что бы вы хотели обсудить?",
      sendBtn: "Отправить Сообщение",
      successTitle: "Сообщение Успешно Отправлено!",
      successDesc: "Спасибо за обращение. Я свяжусь с вами как можно скорее."
    },
    footer: {
      rights: "Все права защищены."
    },
    preloader: {
      sub: "КРЕАТИВНЫЙ РАЗРАБОТЧИК"
    },
    settings: {
      theme: "Тема",
      dark: "Темная",
      light: "Светлая",
      language: "Язык",
      currentLanguage: "Текущий язык"
    }
  },
  zh: {
    nav: {
      home: "首页",
      profile: "个人资料",
      about: "关于我",
      projects: "项目",
      stats: "统计",
      skills: "技能",
      companies: "公司",
      faq: "常见问题",
      contact: "联系我们",
      settings: "设置"
    },
    hero: {
      greeting: "你好，我是",
      name: "Blacker",
      title: "全栈开发工程师",
      skills: [
        "后端架构",
        "Python 爬虫与自动化",
        "React 交互界面",
        "高性能 Node.js API"
      ],
      tagline: "构建高性能后端服务和流畅的用户界面。",
      ctaWork: "查看作品",
      ctaTalk: "联系我"
    },
    about: {
      title: "关于我",
      greeting: "你好，我是 Blacker。",
      summary: "我是一名全栈开发者，热爱设计和构建高性能后端系统和引人入胜的交互式前端。我的主要工具包括 Node.js、Python 和现代 Web 技术。我专注于清晰的架构、安全和流畅的用户体验。",
      location: "生活在",
      highlights: [
        {
          title: "后端专家",
          desc: "擅长使用 Node.js 和 Python 构建稳健的 REST 和 GraphQL API、微服务和 WebSocket。"
        },
        {
          title: "前端细节",
          desc: "使用 React、现代 CSS 和动画制作完全响应式、交互式和高性能的用户界面。"
        },
        {
          title: "自动化与工具",
          desc: "使用 Python 创建脚本、爬虫和自动化管道，简化工作流程并解析复杂数据。"
        }
      ]
    },
    projects: {
      title: "精选项目",
      subtitle: "展示了一组稳健的、容器化的、基于 Canvas 的 Discord 应用系统，旨在提升社区管理体验。",
      ctaDownload: "获取 / 邀请",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "音频流"],
          desc: "一个高度可靠的机器人，可生成项目和代码，完全免费使用。"
        },
        {
          title: "Votes",
          tags: ["Python", "天文 API", "Node.js", "Cron 调度"],
          desc: "自动计算和管理投票系统，具有精确的分析和实时结果。"
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "并发控制"],
          desc: "用于支持系统的高级工单管理机器人，具有隔离的数据库存储和快速工单创建功能。"
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "年经验" },
        { value: "50k+", label: "行干净代码" },
        { value: "100%", label: "系统正常运行时间" }
      ]
    },
    philosophy: {
      quote: "软件工程不仅仅是编写代码；更是构建稳健的数字架构，使其在规模扩展时保持弹性。",
      author: "Blacker 的哲学"
    },
    skills: {
      title: "技能与工作流程",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CLEAN CODE", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "SCALING", "GIT", "REST"]
    },
    faq: {
      title: "常见问题",
      items: [
        {
          q: "您偏好的后端技术栈是什么？",
          a: "我偏好使用 Node.js（使用 Express 或 Fastify）构建高并发、高性能的 REST 或 GraphQL API，同时使用 Python（FastAPI 或 Django）进行工作流自动化和实用脚本编写。"
        },
        {
          q: "您会构建全栈 Web 应用吗？",
          a: "是的。我将稳健、高性能的后端系统和数据库（Node.js 和 Python）与使用 React 和现代布局架构构建的极快、优雅、交互式的用户界面相结合。"
        },
        {
          q: "您如何处理自动化和数据抓取？",
          a: "我开发高度可靠的定制 Python 自动化管道，旨在从复杂的 Web 界面中提取和结构化数据，帮助企业优化运营并简化手动工作流程。"
        },
        {
          q: "您是否接受远程工作和合同项目？",
          a: "是的，我完全接受远程合同机会、技术咨询以及从概念到部署的端到端系统开发。"
        }
      ]
    },
    contact: {
      title: "联系我",
      subtitle: "让我们构建一些很棒的东西",
      desc: "无论您是想讨论使用 Node.js 或 Python 的后端架构，需要 React 的动态布局，还是只是想建立联系，请随时发送消息！",
      emailLabel: "发送邮件",
      locationLabel: "位置",
      locationValue: "埃及",
      nameField: "姓名",
      namePlaceholder: "输入您的姓名",
      emailField: "邮箱",
      emailPlaceholder: "输入您的邮箱",
      messageField: "消息",
      messagePlaceholder: "您想讨论什么？",
      sendBtn: "发送消息",
      successTitle: "消息发送成功！",
      successDesc: "感谢您的联系。我会尽快回复您。"
    },
    footer: {
      rights: "版权所有。"
    },
    preloader: {
      sub: "创意开发者"
    },
    settings: {
      theme: "主题",
      dark: "深色",
      light: "浅色",
      language: "语言",
      currentLanguage: "当前语言"
    }
  },
  ja: {
    nav: {
      home: "ホーム",
      profile: "プロフィール",
      about: "について",
      projects: "プロジェクト",
      stats: "統計",
      skills: "スキル",
      companies: "企業",
      faq: "よくある質問",
      contact: "お問い合わせ",
      settings: "設定"
    },
    hero: {
      greeting: "こんにちは、私は",
      name: "Blacker",
      title: "フルスタック開発者＆エンジニア",
      skills: [
        "バックエンドアーキテクチャ",
        "Pythonスクレイパー＆自動化",
        "Reactインタラクティブインターフェース",
        "高性能Node.js API"
      ],
      tagline: "高性能なバックエンドサービスとスムーズなユーザーインターフェースを構築しています。",
      ctaWork: "作品を見る",
      ctaTalk: "話しましょう"
    },
    about: {
      title: "私について",
      greeting: "こんにちは、私はBlackerです。",
      summary: "私はフルスタック開発者で、高性能なバックエンドシステムと魅力的でインタラクティブなフロントエンドの設計と構築が大好きです。主なツールにはNode.js、Python、最新のWeb技術が含まれます。クリーンなアーキテクチャ、セキュリティ、スムーズなユーザー体験に焦点を当てています。",
      location: "在住",
      highlights: [
        {
          title: "バックエンドスペシャリスト",
          desc: "Node.jsとPythonを使用した堅牢なRESTおよびGraphQL API、マイクロサービス、WebSocketの構築に豊富な経験があります。"
        },
        {
          title: "フロントエンドの細部",
          desc: "React、モダンCSS、アニメーションを使用して、完全にレスポンシブでインタラクティブな高性能ユーザーインターフェースを作成します。"
        },
        {
          title: "自動化とツール",
          desc: "Pythonを使用してスクリプト、スクレイパー、自動化パイプラインを作成し、ワークフローを簡素化し複雑なデータを解析します。"
        }
      ]
    },
    projects: {
      title: "注目プロジェクト",
      subtitle: "コミュニティ管理を向上させるために設計された、堅牢でコンテナ化されたCanvasベースのDiscordアプリケーションシステムのショーケースです。",
      ctaDownload: "取得 / 招待",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "オーディオストリーム"],
          desc: "プロジェクトとコードを生成する高信頼性ボットで、完全に無料で使用できます。"
        },
        {
          title: "Votes",
          tags: ["Python", "天文API", "Node.js", "Cronスケジューリング"],
          desc: "投票システムを自動的に計算・管理し、正確な分析とリアルタイムの結果を提供します。"
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "並行性制御"],
          desc: "分離されたデータベースストレージと迅速なチケット作成を備えた、サポートシステム用の高度なチケット管理ボットです。"
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "年の経験" },
        { value: "50k+", label: "行のクリーンコード" },
        { value: "100%", label: "システム稼働率の重視" }
      ]
    },
    philosophy: {
      quote: "ソフトウェアエンジニアリングは単にコードを書くことではなく、スケールに耐える堅牢なデジタルアーキテクチャを作り上げることです。",
      author: "Blackerの哲学"
    },
    skills: {
      title: "スキルとワークフロー",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CLEAN CODE", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "SCALING", "GIT", "REST"]
    },
    faq: {
      title: "よくある質問",
      items: [
        {
          q: "あなたの好みのバックエンドテクノロジースタックは何ですか？",
          a: "Node.js（ExpressまたはFastifyを使用）で高並行性で高性能なRESTまたはGraphQL APIを構築し、Python（FastAPIまたはDjango）でワークフローの自動化とユーティリティスクリプトを作成することを好みます。"
        },
        {
          q: "フルスタックWebアプリケーションを構築しますか？",
          a: "はい。堅牢で高性能なバックエンドシステムとデータベース（Node.jsとPython）を、Reactとモダンレイアウトアーキテクチャを使用した非常に高速でエレガントなインタラクティブユーザーインターフェースと組み合わせています。"
        },
        {
          q: "自動化とデータスクレイピングをどのように処理しますか？",
          a: "複雑なWebインターフェースからデータを抽出・構造化するために設計された、高信頼性のカスタムPython自動化パイプラインを開発し、企業が運用を最適化し手動ワークフローを効率化するのに役立てています。"
        },
        {
          q: "リモートワークや契約プロジェクトは可能ですか？",
          a: "はい、リモート契約の機会、技術コンサルティング、コンセプトからデプロイまでのエンドツーエンドシステム開発に完全に対応可能です。"
        }
      ]
    },
    contact: {
      title: "お問い合わせ",
      subtitle: "素晴らしいものを一緒に作りましょう",
      desc: "Node.jsやPythonを使用したバックエンドアーキテクチャの議論、Reactでの動的レイアウトの必要性、または単に繋がりたい場合でも、お気軽にメッセージをお送りください！",
      emailLabel: "メールを送る",
      locationLabel: "所在地",
      locationValue: "エジプト",
      nameField: "名前",
      namePlaceholder: "お名前を入力してください",
      emailField: "メール",
      emailPlaceholder: "メールアドレスを入力してください",
      messageField: "メッセージ",
      messagePlaceholder: "何について話し合いたいですか？",
      sendBtn: "メッセージを送信",
      successTitle: "メッセージ送信成功！",
      successDesc: "お問い合わせありがとうございます。できるだけ早く返信いたします。"
    },
    footer: {
      rights: "All rights reserved."
    },
    preloader: {
      sub: "CREATIVE DEVELOPER"
    },
    settings: {
      theme: "テーマ",
      dark: "ダーク",
      light: "ライト",
      language: "言語",
      currentLanguage: "現在の言語"
    }
  },
  ko: {
    nav: {
      home: "홈",
      profile: "프로필",
      about: "소개",
      projects: "프로젝트",
      stats: "통계",
      skills: "기술",
      companies: "회사",
      faq: "FAQ",
      contact: "연락처",
      settings: "설정"
    },
    hero: {
      greeting: "안녕하세요, 저는",
      name: "Blacker",
      title: "풀스택 개발자 & 엔지니어",
      skills: [
        "백엔드 아키텍처",
        "Python 스크레이퍼 & 자동화",
        "React 인터랙티브 인터페이스",
        "고성능 Node.js API"
      ],
      tagline: "고성능 백엔드 서비스와 유연한 사용자 인터페이스를 구축합니다.",
      ctaWork: "작업 보기",
      ctaTalk: "대화하기"
    },
    about: {
      title: "소개",
      greeting: "안녕하세요, 저는 Blacker입니다.",
      summary: "저는 고성능 백엔드 시스템과 매력적인 인터랙티브 프론트엔드를 설계하고 구축하는 것을 좋아하는 풀스택 개발자입니다. 주요 도구로는 Node.js, Python, 현대 웹 기술이 포함됩니다. 깔끔한 아키텍처, 보안, 부드러운 사용자 경험에 중점을 둡니다.",
      location: "거주지",
      highlights: [
        {
          title: "백엔드 전문가",
          desc: "Node.js와 Python을 사용한 강력한 REST 및 GraphQL API, 마이크로서비스, 웹소켓 구축에 풍부한 경험을 보유하고 있습니다."
        },
        {
          title: "프론트엔드 디테일",
          desc: "React, 모던 CSS, 애니메이션을 사용하여 완전히 반응형이고 인터랙티브한 고성능 사용자 인터페이스를 제작합니다."
        },
        {
          title: "자동화 및 도구",
          desc: "Python을 사용하여 워크플로를 단순화하고 복잡한 데이터를 분석하는 스크립트, 스크레이퍼, 자동화 파이프라인을 만듭니다."
        }
      ]
    },
    projects: {
      title: "주요 프로젝트",
      subtitle: "커뮤니티 관리를 향상시키기 위해 설계된 강력하고 컨테이너화된 Canvas 기반 Discord 애플리케이션 시스템을 소개합니다.",
      ctaDownload: "획득 / 초대",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "오디오 스트림"],
          desc: "프로젝트와 코드를 생성하는 고신뢰성 봇으로, 완전 무료로 사용할 수 있습니다."
        },
        {
          title: "Votes",
          tags: ["Python", "천문 API", "Node.js", "Cron 스케줄링"],
          desc: "투표 시스템을 자동으로 계산하고 관리하며 정확한 분석과 실시간 결과를 제공합니다."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "동시성 제어"],
          desc: "분리된 데이터베이스 스토리지와 빠른 티켓 생성을 갖춘 지원 시스템용 고급 티켓 관리 봇입니다."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "년 경력" },
        { value: "50k+", label: "줄의 클린 코드" },
        { value: "100%", label: "시스템 가동률 중점" }
      ]
    },
    philosophy: {
      quote: "소프트웨어 엔지니어링은 단순히 코드를 작성하는 것이 아니라, 확장에 견고하게 견디는 디지털 아키텍처를 만드는 것입니다.",
      author: "Blacker의 철학"
    },
    skills: {
      title: "기술 및 워크플로",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CLEAN CODE", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "SCALING", "GIT", "REST"]
    },
    faq: {
      title: "자주 묻는 질문",
      items: [
        {
          q: "선호하는 백엔드 기술 스택은 무엇인가요?",
          a: "Node.js(Express 또는 Fastify 사용)로 고동시성 및 고성능 REST 또는 GraphQL API를 구축하고, Python(FastAPI 또는 Django)으로 워크플로 자동화 및 유틸리티 스크립팅을 하는 것을 선호합니다."
        },
        {
          q: "풀스택 웹 애플리케이션을 구축하시나요?",
          a: "네. 강력하고 고성능인 백엔드 시스템과 데이터베이스(Node.js 및 Python)를 React와 현대 레이아웃 아키텍처를 사용한 매우 빠르고 우아한 인터랙티브 사용자 인터페이스와 결합합니다."
        },
        {
          q: "자동화와 데이터 스크레이핑을 어떻게 처리하시나요?",
          a: "복잡한 웹 인터페이스에서 데이터를 추출하고 구조화하도록 설계된 고신뢰성의 맞춤형 Python 자동화 파이프라인을 개발하여 기업이 운영을 최적화하고 수동 워크플로를 간소화하도록 돕습니다."
        },
        {
          q: "원격 근무 및 계약 프로젝트가 가능한가요?",
          a: "네, 원격 계약 기회, 기술 컨설팅, 컨셉에서 배포까지의 엔드투엔드 시스템 개발에 완전히 가능합니다."
        }
      ]
    },
    contact: {
      title: "연락하기",
      subtitle: "멋진 것을 함께 만들어요",
      desc: "Node.js나 Python을 사용한 백엔드 아키텍처를 논의하거나, React의 동적 레이아웃이 필요하거나, 단순히 연결하고 싶다면 언제든지 메시지를 보내주세요!",
      emailLabel: "이메일 보내기",
      locationLabel: "위치",
      locationValue: "이집트",
      nameField: "이름",
      namePlaceholder: "이름을 입력하세요",
      emailField: "이메일",
      emailPlaceholder: "이메일을 입력하세요",
      messageField: "메시지",
      messagePlaceholder: "무엇에 대해 논의하고 싶으신가요?",
      sendBtn: "메시지 보내기",
      successTitle: "메시지 전송 성공!",
      successDesc: "연락해 주셔서 감사합니다. 최대한 빨리 답변 드리겠습니다."
    },
    footer: {
      rights: "All rights reserved."
    },
    preloader: {
      sub: "CREATIVE DEVELOPER"
    },
    settings: {
      theme: "테마",
      dark: "다크",
      light: "라이트",
      language: "언어",
      currentLanguage: "현재 언어"
    }
  },
  hi: {
    nav: {
      home: "होम",
      profile: "प्रोफ़ाइल",
      about: "मेरे बारे में",
      projects: "प्रोजेक्ट्स",
      stats: "आँकड़े",
      skills: "कौशल",
      companies: "कंपनियाँ",
      faq: "सामान्य प्रश्न",
      contact: "संपर्क करें",
      settings: "सेटिंग्स"
    },
    hero: {
      greeting: "नमस्ते, मैं",
      name: "Blacker",
      title: "फुल-स्टैक डेवलपर और इंजीनियर",
      skills: [
        "बैकएंड आर्किटेक्चर",
        "Python स्क्रैपर्स और स्वचालन",
        "React इंटरैक्टिव इंटरफेस",
        "उच्च-प्रदर्शन Node.js API"
      ],
      tagline: "उच्च-प्रदर्शन बैकएंड सेवाएँ और सुगम उपयोगकर्ता इंटरफेस बना रहा हूँ।",
      ctaWork: "काम देखें",
      ctaTalk: "बात करें"
    },
    about: {
      title: "मेरे बारे में",
      greeting: "नमस्ते, मैं Blacker हूँ।",
      summary: "मैं एक फुल-स्टैक डेवलपर हूँ जो उच्च-प्रदर्शन बैकएंड सिस्टम और आकर्षक, इंटरैक्टिव फ्रंटएंड डिज़ाइन करना और बनाना पसंद करता है। मेरे मुख्य टूलकिट में Node.js, Python और आधुनिक वेब तकनीकें शामिल हैं। मैं स्वच्छ आर्किटेक्चर, सुरक्षा और सुगम उपयोगकर्ता अनुभव पर ध्यान केंद्रित करता हूँ।",
      location: "में रहता हूँ",
      highlights: [
        {
          title: "बैकएंड विशेषज्ञ",
          desc: "Node.js और Python का उपयोग करके मजबूत REST और GraphQL API, माइक्रोसर्विसेज़ और वेब सॉकेट बनाने में अनुभवी।"
        },
        {
          title: "फ्रंटएंड विवरण",
          desc: "React, आधुनिक CSS और एनिमेशन का उपयोग करके पूरी तरह से प्रतिक्रियाशील, इंटरैक्टिव और उच्च-प्रदर्शन उपयोगकर्ता इंटरफेस तैयार करना।"
        },
        {
          title: "स्वचालन और उपकरण",
          desc: "Python के साथ स्क्रिप्ट, स्क्रैपर और स्वचालन पाइपलाइन बनाना ताकि वर्कफ़्लो को सरल बनाया जा सके और जटिल डेटा को पार्स किया जा सके।"
        }
      ]
    },
    projects: {
      title: "प्रमुख प्रोजेक्ट्स",
      subtitle: "समुदाय प्रबंधन को बेहतर बनाने के लिए डिज़ाइन किए गए मजबूत, कंटेनरीकृत और कैनवास-संचालित Discord एप्लिकेशन सिस्टम का एक प्रदर्शन।",
      ctaDownload: "प्राप्त करें / आमंत्रित करें",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "ऑडियो स्ट्रीम"],
          desc: "एक अत्यधिक विश्वसनीय बॉट जो प्रोजेक्ट और कोड उत्पन्न करता है, पूरी तरह से मुफ्त।"
        },
        {
          title: "Votes",
          tags: ["Python", "खगोल विज्ञान API", "Node.js", "Cron शेड्यूलिंग"],
          desc: "सटीक विश्लेषण और वास्तविक समय के परिणामों के साथ स्वचालित रूप से वोटिंग सिस्टम की गणना और प्रबंधन करता है।"
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "समवर्ती नियंत्रण"],
          desc: "पृथक डेटाबेस भंडारण और त्वरित टिकट निर्माण के साथ सहायता प्रणालियों के लिए उन्नत टिकट प्रबंधन बॉट।"
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "वर्षों का अनुभव" },
        { value: "50k+", label: "स्वच्छ कोड की पंक्तियाँ" },
        { value: "100%", label: "सिस्टम अपटाइम पर ध्यान" }
      ]
    },
    philosophy: {
      quote: "सॉफ्टवेयर इंजीनियरिंग केवल कोड लिखने के बारे में नहीं है; यह मजबूत डिजिटल आर्किटेक्चर तैयार करने के बारे है जो पैमाने पर मजबूत बनी रहती है।",
      author: "Blacker का दर्शन"
    },
    skills: {
      title: "कौशल और कार्यप्रवाह",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CLEAN CODE", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANCE", "SCALING", "GIT", "REST"]
    },
    faq: {
      title: "सामान्य प्रश्न",
      items: [
        {
          q: "आपका पसंदीदा बैकएंड तकनीक स्टैक क्या है?",
          a: "मैं Node.js (Express या Fastify का उपयोग करके) के साथ अत्यधिक समवर्ती और प्रदर्शनशील REST या GraphQL API बनाना पसंद करता हूँ, साथ ही वर्कफ़्लो स्वचालन और उपयोगिता स्क्रिप्टिंग के लिए Python (FastAPI या Django) भी।"
        },
        {
          q: "क्या आप फुल-स्टैक वेब एप्लिकेशन बनाते हैं?",
          a: "हाँ। मैं मजबूत, उच्च-प्रदर्शन बैकएंड सिस्टम और डेटाबेस (Node.js और Python) को React और आधुनिक लेआउट आर्किटेक्चर का उपयोग करके अत्यंत तेज़, सुरुचिपूर्ण और इंटरैक्टिव उपयोगकर्ता इंटरफेस के साथ जोड़ता हूँ।"
        },
        {
          q: "आप स्वचालन और डेटा स्क्रैपिंग कैसे संभालते हैं?",
          a: "मैं अत्यधिक विश्वसनीय, कस्टम Python स्वचालन पाइपलाइन विकसित करता हूँ जो जटिल वेब इंटरफेस से डेटा निकालने और संरचित करने के लिए डिज़ाइन की गई हैं, व्यवसायों को संचालन को अनुकूलित करने और मैन्युअल वर्कफ़्लो को सुव्यवस्थित करने में मदद करती हैं।"
        },
        {
          q: "क्या आप रिमोट कार्य और अनुबंध परियोजनाओं के लिए उपलब्ध हैं?",
          a: "हाँ, मैं रिमोट अनुबंध के अवसरों, तकनीकी परामर्श, और अवधारणा से तैनाती तक एंड-टू-एंड सिस्टम विकास के लिए पूरी तरह से उपलब्ध हूँ।"
        }
      ]
    },
    contact: {
      title: "संपर्क करें",
      subtitle: "आइए कुछ शानदार बनाएँ",
      desc: "चाहे आप Node.js या Python का उपयोग करके बैकएंड आर्किटेक्चर पर चर्चा करना चाहते हों, React में डायनामिक लेआउट की आवश्यकता हो, या बस जुड़ना चाहते हों, संदेश भेजने में संकोच न करें!",
      emailLabel: "मुझे ईमेल करें",
      locationLabel: "स्थान",
      locationValue: "मिस्र",
      nameField: "नाम",
      namePlaceholder: "अपना नाम दर्ज करें",
      emailField: "ईमेल",
      emailPlaceholder: "अपना ईमेल दर्ज करें",
      messageField: "संदेश",
      messagePlaceholder: "आप किस बारे में चर्चा करना चाहेंगे?",
      sendBtn: "संदेश भेजें",
      successTitle: "संदेश सफलतापूर्वक भेजा गया!",
      successDesc: "संपर्क करने के लिए धन्यवाद। मैं जल्द से जल्द आपसे संपर्क करूंगा।"
    },
    footer: {
      rights: "All rights reserved."
    },
    preloader: {
      sub: "CREATIVE DEVELOPER"
    },
    settings: {
      theme: "थीम",
      dark: "डार्क",
      light: "लाइट",
      language: "भाषा",
      currentLanguage: "वर्तमान भाषा"
    }
  },
  tr: {
    nav: {
      home: "Ana Sayfa",
      profile: "Profil",
      about: "Hakkımda",
      projects: "Projeler",
      stats: "İstatistikler",
      skills: "Yetenekler",
      companies: "Şirketler",
      faq: "SSS",
      contact: "İletişim",
      settings: "Ayarlar"
    },
    hero: {
      greeting: "Merhaba, ben",
      name: "Blacker",
      title: "Full-Stack Geliştirici ve Mühendis",
      skills: [
        "Backend Mimarisi",
        "Python Scraper ve Otomasyon",
        "React Etkileşimli Arayüzler",
        "Yüksek Performanslı Node.js API'leri"
      ],
      tagline: "Yüksek performanslı backend hizmetleri ve akıcı kullanıcı arayüzleri oluşturuyorum.",
      ctaWork: "Çalışmaları Gör",
      ctaTalk: "Konuşalım"
    },
    about: {
      title: "Hakkımda",
      greeting: "Merhaba, ben Blacker.",
      summary: "Yüksek performanslı backend sistemleri ve ilgi çekici, etkileşimli frontend'ler tasarlamayı ve oluşturmayı seven bir full-stack geliştiriciyim. Ana araç setim Node.js, Python ve modern web teknolojilerini içerir. Temiz mimari, güvenlik ve akıcı kullanıcı deneyimlerine odaklanıyorum.",
      location: "Yaşadığım yer",
      highlights: [
        {
          title: "Backend Uzmanı",
          desc: "Node.js ve Python kullanarak sağlam REST ve GraphQL API'leri, mikro hizmetler ve web soketleri oluşturma konusunda deneyimli."
        },
        {
          title: "Frontend Detay",
          desc: "React, modern CSS ve animasyonlar kullanarak tamamen duyarlı, etkileşimli ve yüksek performanslı kullanıcı arayüzleri oluşturma."
        },
        {
          title: "Otomasyon ve Araçlar",
          desc: "Python ile iş akışlarını basitleştirmek ve karmaşık verileri ayrıştırmak için script, scraper ve otomasyon hatları oluşturma."
        }
      ]
    },
    projects: {
      title: "Öne Çıkan Projeler",
      subtitle: "Topluluk yönetimini geliştirmek için tasarlanmış sağlam, konteynerize edilmiş ve canvas destekli Discord uygulama sistemlerinden oluşan bir vitrin.",
      ctaDownload: "Al / Davet Et",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Ses Akışı"],
          desc: "Projeler ve kodlar oluşturan, tamamen ücretsiz, yüksek güvenilirliğe sahip bir bot."
        },
        {
          title: "Votes",
          tags: ["Python", "Astronomi API", "Node.js", "Cron Planlama"],
          desc: "Hassas analiz ve gerçek zamanlı sonuçlarla oylama sistemlerini otomatik olarak hesaplar ve yönetir."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Eşzamanlılık Kontrolü"],
          desc: "İzole veritabanı depolama ve hızlı bilet oluşturma ile destek sistemleri için gelişmiş bilet yönetim botu."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Yıl Deneyim" },
        { value: "50k+", label: "Satır Temiz Kod" },
        { value: "100%", label: "Sistem Çalışma Süresi Odağı" }
      ]
    },
    philosophy: {
      quote: "Yazılım mühendisliği sadece kod yazmak değildir; ölçek altında dayanıklı kalan sağlam dijital mimari oluşturmaktır.",
      author: "Blacker'ın Felsefesi"
    },
    skills: {
      title: "Yetenekler ve İş Akışı",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["TEMİZ KOD", "MONGODB", "POSTGRESQL", "DOCKER", "PERFORMANS", "ÖLÇEKLENDİRME", "GIT", "REST"]
    },
    faq: {
      title: "Sıkça Sorulan Sorular",
      items: [
        {
          q: "Tercih ettiğiniz backend teknoloji yığını nedir?",
          a: "Node.js (Express veya Fastify kullanarak) ile yüksek eşzamanlı ve performanslı REST veya GraphQL API'leri oluşturmayı ve iş akışı otomasyonu ile yardımcı script'ler için Python (FastAPI veya Django) kullanmayı tercih ediyorum."
        },
        {
          q: "Full-stack web uygulamaları geliştiriyor musunuz?",
          a: "Evet. Sağlam, yüksek performanslı backend sistemleri ve veritabanlarını (Node.js ve Python) React ve modern layout mimarileri kullanarak son derece hızlı, şık ve etkileşimli kullanıcı arayüzleriyle birleştiriyorum."
        },
        {
          q: "Otomasyon ve veri kazımayı nasıl yapıyorsunuz?",
          a: "Karmaşık web arayüzlerinden veri çıkarmak ve yapılandırmak için tasarlanmış, yüksek güvenilirliğe sahip özel Python otomasyon hatları geliştiriyorum, işletmelerin operasyonlarını optimize etmelerine ve manuel iş akışlarını düzene sokmalarına yardımcı oluyorum."
        },
        {
          q: "Uzaktan çalışma ve sözleşmeli projeler için müsait misiniz?",
          a: "Evet, uzaktan sözleşme fırsatları, teknik danışmanlık ve kavramsallaştırmadan dağıtıma kadar uçtan uca sistem geliştirme için tamamen müsaitim."
        }
      ]
    },
    contact: {
      title: "İletişime Geçin",
      subtitle: "Harika bir şey inşa edelim",
      desc: "Node.js veya Python kullanarak bir backend mimarisini tartışmak, React'te dinamik düzenlere ihtiyaç duymak veya sadece bağlantı kurmak isterseniz, bir mesaj göndermekten çekinmeyin!",
      emailLabel: "E-posta Gönder",
      locationLabel: "Konum",
      locationValue: "Mısır",
      nameField: "İsim",
      namePlaceholder: "Adınızı girin",
      emailField: "E-posta",
      emailPlaceholder: "E-postanızı girin",
      messageField: "Mesaj",
      messagePlaceholder: "Ne hakkında konuşmak istersiniz?",
      sendBtn: "Mesaj Gönder",
      successTitle: "Mesaj Başarıyla Gönderildi!",
      successDesc: "İletişime geçtiğiniz için teşekkürler. En kısa sürede size dönüş yapacağım."
    },
    footer: {
      rights: "Tüm hakları saklıdır."
    },
    preloader: {
      sub: "YARATICI GELİŞTİRİCİ"
    },
    settings: {
      theme: "Tema",
      dark: "Koyu",
      light: "Açık",
      language: "Dil",
      currentLanguage: "Mevcut Dil"
    }
  },
  nl: {
    nav: {
      home: "Home",
      profile: "Profiel",
      about: "Over mij",
      projects: "Projecten",
      stats: "Statistieken",
      skills: "Vaardigheden",
      companies: "Bedrijven",
      faq: "FAQ",
      contact: "Contact",
      settings: "Instellingen"
    },
    hero: {
      greeting: "Hallo, ik ben",
      name: "Blacker",
      title: "Full-Stack Ontwikkelaar & Engineer",
      skills: [
        "Backend Architectuur",
        "Python Scrapers & Automatisering",
        "React Interactieve Interfaces",
        "Hoogpresterende Node.js API's"
      ],
      tagline: "Ik bouw hoogpresterende backend-services en vloeiende gebruikersinterfaces.",
      ctaWork: "Bekijk Werk",
      ctaTalk: "Laten we praten"
    },
    about: {
      title: "Over mij",
      greeting: "Hallo, ik ben Blacker.",
      summary: "Ik ben een full-stack ontwikkelaar die graag hoogpresterende backendsystemen en boeiende, interactieve frontends ontwerpt en bouwt. Mijn belangrijkste toolkit omvat Node.js, Python en moderne webtechnologieën. Ik focus op schone architectuur, veiligheid en soepele gebruikerservaringen.",
      location: "Woonachtig in",
      highlights: [
        {
          title: "Backend Specialist",
          desc: "Ervaren in het bouwen van robuuste REST en GraphQL API's, microservices en websockets met Node.js en Python."
        },
        {
          title: "Frontend Detail",
          desc: "Het maken van volledig responsieve, interactieve en hoogpresterende gebruikersinterfaces met React, moderne CSS en animaties."
        },
        {
          title: "Automatisering & Tools",
          desc: "Het creëren van scripts, scrapers en automatiseringspijplijnen met Python om workflows te vereenvoudigen en complexe gegevens te parseren."
        }
      ]
    },
    projects: {
      title: "Uitgelichte Projecten",
      subtitle: "Een showcase van robuuste, gecontaineriseerde en canvas-ondersteunde Discord-applicatiesystemen gebouwd om communitybeheer te verbeteren.",
      ctaDownload: "Krijg / Nodig uit",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Audio Stream"],
          desc: "Een zeer betrouwbare bot die projecten en codes genereert, volledig gratis te gebruiken."
        },
        {
          title: "Votes",
          tags: ["Python", "Astronomie API", "Node.js", "Cron Planning"],
          desc: "Berekent en beheert automatisch stemsystemen met nauwkeurige analyses en real-time resultaten."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Gelijktijdigheidscontrole"],
          desc: "Geavanceerde ticketbeheerbot voor ondersteuningssystemen met geïsoleerde databaseopslag en snelle ticketcreatie."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Jaar Ervaring" },
        { value: "50k+", label: "Regels Schone Code" },
        { value: "100%", label: "Focus op Systeemuptime" }
      ]
    },
    philosophy: {
      quote: "Software-engineering gaat niet alleen over het schrijven van code; het gaat over het maken van robuuste digitale architectuur die veerkrachtig blijft onder schaal.",
      author: "Blacker's Filosofie"
    },
    skills: {
      title: "Vaardigheden & Workflow",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["SCHONE CODE", "MONGODB", "POSTGRESQL", "DOCKER", "PRESTATIES", "SCHALING", "GIT", "REST"]
    },
    faq: {
      title: "Veelgestelde Vragen",
      items: [
        {
          q: "Wat is uw favoriete backend-technologiestack?",
          a: "Ik werk bij voorkeur met Node.js (met Express of Fastify) voor het bouwen van zeer gelijktijdige en performante REST of GraphQL API's, naast Python (FastAPI of Django) voor workflowautomatisering en nutsscripting."
        },
        {
          q: "Bouwt u full-stack webapplicaties?",
          a: "Ja. Ik combineer robuuste, hoogpresterende backendsystemen en databases (Node.js en Python) met extreem snelle, elegante en interactieve gebruikersinterfaces met React en moderne lay-outarchitecturen."
        },
        {
          q: "Hoe gaat u om met automatisering en data scraping?",
          a: "Ik ontwikkel zeer betrouwbare, op maat gemaakte Python-automatiseringspijplijnen die zijn ontworpen om gegevens uit complexe webinterfaces te extraheren en te structureren, waardoor bedrijven hun activiteiten kunnen optimaliseren en handmatige workflows kunnen stroomlijnen."
        },
        {
          q: "Bent u beschikbaar voor extern werk en contractprojecten?",
          a: "Ja, ik ben volledig beschikbaar voor externe contractmogelijkheden, technisch advies en end-to-end systeemontwikkeling van conceptualisatie tot implementatie."
        }
      ]
    },
    contact: {
      title: "Neem Contact Op",
      subtitle: "Laten we iets geweldigs bouwen",
      desc: "Of u nu een backend-architectuur wilt bespreken met Node.js of Python, dynamische lay-outs in React nodig heeft, of gewoon contact wilt maken, voel u vrij om een bericht te sturen!",
      emailLabel: "Stuur E-mail",
      locationLabel: "Locatie",
      locationValue: "Egypte",
      nameField: "Naam",
      namePlaceholder: "Voer uw naam in",
      emailField: "E-mail",
      emailPlaceholder: "Voer uw e-mail in",
      messageField: "Bericht",
      messagePlaceholder: "Waarover wilt u praten?",
      sendBtn: "Verstuur Bericht",
      successTitle: "Bericht Succesvol Verzonden!",
      successDesc: "Bedankt voor uw bericht. Ik neem zo snel mogelijk contact met u op."
    },
    footer: {
      rights: "Alle rechten voorbehouden."
    },
    preloader: {
      sub: "CREATIEVE ONTWIKKELAAR"
    },
    settings: {
      theme: "Thema",
      dark: "Donker",
      light: "Licht",
      language: "Taal",
      currentLanguage: "Huidige taal"
    }
  },
  pl: {
    nav: {
      home: "Strona główna",
      profile: "Profil",
      about: "O mnie",
      projects: "Projekty",
      stats: "Statystyki",
      skills: "Umiejętności",
      companies: "Firmy",
      faq: "FAQ",
      contact: "Kontakt",
      settings: "Ustawienia"
    },
    hero: {
      greeting: "Cześć, jestem",
      name: "Blacker",
      title: "Full-Stack Developer i Inżynier",
      skills: [
        "Architektura Backend",
        "Scrapery Python i Automatyzacja",
        "Interaktywne Interfejsy React",
        "Wydajne API Node.js"
      ],
      tagline: "Buduję wydajne usługi backendowe i płynne interfejsy użytkownika.",
      ctaWork: "Zobacz Prace",
      ctaTalk: "Porozmawiajmy"
    },
    about: {
      title: "O mnie",
      greeting: "Cześć, jestem Blacker.",
      summary: "Jestem programistą full-stack, który uwielbia projektować i budować wydajne systemy backendowe oraz angażujące, interaktywne frontendy. Mój główny zestaw narzędzi obejmuje Node.js, Python i nowoczesne technologie internetowe. Skupiam się na czystej architekturze, bezpieczeństwie i płynnych doświadczeniach użytkownika.",
      location: "Mieszkam w",
      highlights: [
        {
          title: "Specjalista Backend",
          desc: "Doświadczony w budowaniu solidnych API REST i GraphQL, mikrousług i gniazd sieciowych przy użyciu Node.js i Python."
        },
        {
          title: "Detal Frontend",
          desc: "Tworzenie w pełni responsywnych, interaktywnych i wydajnych interfejsów użytkownika przy użyciu React, nowoczesnego CSS i animacji."
        },
        {
          title: "Automatyzacja i Narzędzia",
          desc: "Tworzenie skryptów, scraperów i potoków automatyzacji w Pythonie w celu uproszczenia przepływów pracy i analizowania złożonych danych."
        }
      ]
    },
    projects: {
      title: "Wyróżnione Projekty",
      subtitle: "Prezentacja solidnych, skonteneryzowanych systemów aplikacji Discord opartych na canvas, zaprojektowanych w celu usprawnienia zarządzania społecznością.",
      ctaDownload: "Pobierz / Zaproś",
      list: [
        {
          title: "Genprojects",
          tags: ["Node.js", "Discord.js", "FFmpeg", "Strumień Audio"],
          desc: "Wysoce niezawodny bot, który generuje projekty i kody, całkowicie darmowy."
        },
        {
          title: "Votes",
          tags: ["Python", "API Astronomia", "Node.js", "Planowanie Cron"],
          desc: "Automatycznie oblicza i zarządza systemami głosowania z precyzyjną analityką i wynikami w czasie rzeczywistym."
        },
        {
          title: "Ticket",
          tags: ["Docker", "MongoDB", "Node.js", "Kontrola Współbieżności"],
          desc: "Zaawansowany bot zarządzania zgłoszeniami dla systemów wsparcia z izolowanym przechowywaniem w bazie danych i szybkim tworzeniem zgłoszeń."
        }
      ]
    },
    stats: {
      items: [
        { value: "03+", label: "Lata Doświadczenia" },
        { value: "50k+", label: "Linii Czystego Kodu" },
        { value: "100%", label: "Skupienie na Czasie Pracy Systemu" }
      ]
    },
    philosophy: {
      quote: "Inżynieria oprogramowania to nie tylko pisanie kodu; to tworzenie solidnej architektury cyfrowej, która pozostaje odporna w skali.",
      author: "Filozofia Blackera"
    },
    skills: {
      title: "Umiejętności i Przepływ Pracy",
      tickerRow1: ["NODE.JS", "PYTHON", "REACT", "JAVASCRIPT", "APIS", "AUTOMATION", "FASTAPI", "EXPRESS"],
      tickerRow2: ["CZYSTY KOD", "MONGODB", "POSTGRESQL", "DOCKER", "WYDAJNOŚĆ", "SKALOWANIE", "GIT", "REST"]
    },
    faq: {
      title: "Często Zadawane Pytania",
      items: [
        {
          q: "Jaki jest Twój preferowany stos technologii backendowych?",
          a: "Wolę pracować z Node.js (przy użyciu Express lub Fastify) do tworzenia wysoce współbieżnych i wydajnych API REST lub GraphQL, wraz z Pythonem (FastAPI lub Django) do automatyzacji przepływów pracy i skryptów narzędziowych."
        },
        {
          q: "Czy tworzysz aplikacje internetowe full-stack?",
          a: "Tak. Łączę solidne, wydajne systemy backendowe i bazy danych (Node.js i Python) z niezwykle szybkimi, eleganckimi i interaktywnymi interfejsami użytkownika przy użyciu React i nowoczesnych architektur układów."
        },
        {
          q: "Jak radzisz sobie z automatyzacją i zbieraniem danych?",
          a: "Opracowuję wysoce niezawodne, niestandardowe potoki automatyzacji w Pythonie, zaprojektowane do wyodrębniania i strukturyzowania danych ze złożonych interfejsów internetowych, pomagając firmom optymalizować operacje i usprawniać ręczne przepływy pracy."
        },
        {
          q: "Czy jesteś dostępny do pracy zdalnej i projektów kontraktowych?",
          a: "Tak, jestem w pełni dostępny do zdalnych możliwości kontraktowych, konsultacji technicznych i tworzenia systemów od koncepcji do wdrożenia."
        }
      ]
    },
    contact: {
      title: "Skontaktuj się",
      subtitle: "Zbudujmy coś niesamowitego",
      desc: "Niezależnie od tego, czy chcesz omówić architekturę backendu przy użyciu Node.js lub Python, potrzebujesz dynamicznych układów w React, czy po prostu chcesz się połączyć, śmiało wyślij wiadomość!",
      emailLabel: "Wyślij Email",
      locationLabel: "Lokalizacja",
      locationValue: "Egipt",
      nameField: "Imię",
      namePlaceholder: "Wpisz swoje imię",
      emailField: "Email",
      emailPlaceholder: "Wpisz swój email",
      messageField: "Wiadomość",
      messagePlaceholder: "O czym chciałbyś porozmawiać?",
      sendBtn: "Wyślij Wiadomość",
      successTitle: "Wiadomość Wysłana Pomyślnie!",
      successDesc: "Dziękuję za kontakt. Odpowiem tak szybko, jak to możliwe."
    },
    footer: {
      rights: "Wszelkie prawa zastrzeżone."
    },
    preloader: {
      sub: "KREATYWNY PROGRAMISTA"
    },
    settings: {
      theme: "Motyw",
      dark: "Ciemny",
      light: "Jasny",
      language: "Język",
      currentLanguage: "Obecny język"
    }
  }
};