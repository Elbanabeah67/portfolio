// portfolioData.js
export const portfolioData = {
  developerName: "Blacker",
  title: "Full-Stack Developer & Engineer",
  tagline: "Building performant backend services and fluid user interfaces.",
  
  profile: {
    avatar: "https://res.cloudinary.com/difucqa9h/image/upload/v1782951364/discord_images/v5tphul5dm0zyta8cfbu.jpg",
    name: "Blacker",
    username: "5a29",
    discordId: "1251047404636078112",
    discordServerUrl: "https://discord.gg/ec-s",
    youtubeUrl: "https://www.youtube.com/@blacker-DevX",
    role: "Full-Stack Developer & Engineer",
    location: "Egypt"
  },
  
  bio: {
    greeting: "Hi, I'm Blacker.",
    summary: "I'm a full-stack developer who loves designing and building high-performance backend systems and engaging, interactive frontends. My main toolkit includes Node.js, Python, and modern web technologies. I focus on clean architecture, security, and smooth user experiences.",
    highlights: [
      {
        title: "Backend Specialist",
        desc: "Experienced in building robust REST & GraphQL APIs, microservices, and web sockets using Node.js and Python."
      },
      {
        title: "Frontend Detail",
        desc: "Crafting fully responsive, interactive, and high-performance user interfaces using React, modern CSS, and animations."
      },
      {
        title: "Automation & Tools",
        desc: "Creating scripts, scrapers, and automation pipelines with Python to simplify workflows and parse complex data."
      }
    ]
  },
  skills: [
    {
      name: "Node.js",
      category: "backend",
      level: 80,
      description: "Express, Fastify, REST APIs, WebSockets, Async flow"
    },
    {
      name: "Python",
      category: "backend",
      level: 80,
      description: "Scripting, Automation, FastAPI, Django, Data Parsing"
    },
    {
      name: "HTML5 & CSS3",
      category: "frontend",
      level: 80,
      description: "Semantic layouts, Flexbox/Grid, Responsive Design, Custom Properties"
    },
    {
      name: "JavaScript (ES6+)",
      category: "frontend",
      level: 80,
      description: "Modern syntax, Asynchronous Programming, DOM manipulation, React Ecosystem"
    },
    {
      name: "React",
      category: "frontend",
      level: 80,
      description: "Hooks, State management, Context API, Framer Motion integration"
    },
    {
      name: "Git & Workflow",
      category: "tools",
      level: 80,
      description: "Version control, collaborative workflows, CI/CD basics"
    }
  ],
  contact: {
    email: "elbanamohmed37@gmail.com",
    location: "Egypt",
    tiktok: "https://www.tiktok.com/@elbana_xx",
    discord: "https://discord.gg/ec-s",
    instagram: "https://www.instagram.com/elbana_xx1?igsh=NzZyMXA0YXJuNmRj",
    youtube: "https://www.youtube.com/@blacker-DevX"
  }
};